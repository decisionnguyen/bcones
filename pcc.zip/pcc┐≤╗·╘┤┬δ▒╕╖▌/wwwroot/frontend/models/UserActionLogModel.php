<?php
namespace frontend\models;

use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $uid
 * @property string $type
 * @property string $create_time
 * @author Administrator
 *
 */
class UserActionLogModel extends ActiveRecord
{
    
    public static function tableName()
    {
        return "{{%user_action_log}}";
    }
    
    
}