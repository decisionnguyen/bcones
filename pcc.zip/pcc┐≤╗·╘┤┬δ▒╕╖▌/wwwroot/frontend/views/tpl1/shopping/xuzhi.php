<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= WEB_TITLE ?> | 点对点交易须知</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link href="/tpl/css/mui.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/tpl/css/own.css">
    <link rel="stylesheet" href="/tpl/css/public.css">
    <link rel="stylesheet" href="/tpl/css/messinfo.css">
    <style>
        .mui-scroll-wrapper {
            position: absolute;
            z-index: 2;
            top: 44px
        }
    </style>
</head>
<body>
<div class="mui-content" style="padding:0 0 .8rem 0;overflow-y:auto" id="xuzhi">
    <header class="mui-bar mui-bar-nav own-main-background-color">
        <span onclick="javascript :history.go(-1);" class="back mui-icon mui-icon-left-nav mui-pull-left"></span>
        <h1 class="mui-title"> 点对点交易须知 </h1>
    </header>
    <div style="height: 2500px;">
        <div class="mui-scroll">
            <img src="/tpl/img/xuzhi2.jpg" style="width:100%">
        </div>
    </div>
</div>
<script src="/tpl/js/mui.min.js"></script>
<script src="/tpl/js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl/js/libs/vue.min.js" charset="utf-8"></script>
<script src="/tpl/js/function.js" charset="utf-8"></script>
<script>
    // $(".back").click(function () {
    // 	history.back(-1);
    // })
</script>
</body>
</html>