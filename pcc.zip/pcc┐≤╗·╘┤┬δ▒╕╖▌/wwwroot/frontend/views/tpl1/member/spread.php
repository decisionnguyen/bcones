<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= WEB_TITLE ?> | 邀请玩家</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link href="/tpl/css/mui.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/tpl//css/own.css">
    <link rel="stylesheet" href="/tpl//css/public.css">
    <link rel="stylesheet" href="/tpl//css/real_name.css">

</head>
<body>
<header class="mui-bar mui-bar-nav own-main-background-color">
    <span onclick="javascript :history.go(-1);" class="back mui-icon mui-icon-left-nav mui-pull-left"></span>
    <h1 class="mui-title">邀请玩家</h1>
</header>

<div class="mui-content" id="ethpurse">
    <div style="padding:.2rem" v-if="showbtn">
        <div class="show" style="padding:.5rem .4rem">
            <div class="myinfo"><p v-text="name" style="margin-bottom:.2rem"></p>
                <p v-text="address">
                    <!--img src="<?= $img ?>" alt=""-->
					您的邀请码为ID：<br>
					<span><?= Yii::$app->session->get('uid')?>或<?= Yii::$app->session->get('username')?></span>
					 
					<br>
					<img src="/tpl/img/app2.png " alt="" width="180px">
                </p>
            </div>

            <div class="myinfo">
                <p v-text="name" style="margin-bottom:.2rem"></p>
                <p v-text="address">
                   扫码下载APP，填写邀请码注册 
				
                </p>	
            </div>
            <!--input type="text" id="url" readonly value="<?= $url ?>" -->
            <button class="copy" data-clipboard-text="<?= Yii::$app->session->get('username')?>" style="padding: .1rem 1rem;display: block;margin:.5rem auto;color: #fff">复制邀请码</button>
			<p v-text="name" style="margin-bottom:.2rem"></p>
                <p v-text="address">
                    邀请活动：每邀请一位实名认证的玩家，您将获得Ta收益的5%奖励
				
                </p>
        </div>
    </div>
</div>
<script src="/tpl//js/mui.min.js"></script>
<script src="/tpl//js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl//js/libs/vue.min.js" charset="utf-8"></script>
<script src="/tpl/js/libs/clipboard.min.js" charset="utf-8"></script>
<script src="/tpl//js/function.js" charset="utf-8"></script>
<script>
    var clipboard = new Clipboard('.copy');
    clipboard.on('success', function(e) {
        mui.alert('复制成功!')
        e.clearSelection();
    });
    clipboard.on('error', function(e) {
        mui.alert('复制成功!')
        e.clearSelection();
    });

</script>
</body>
</html>