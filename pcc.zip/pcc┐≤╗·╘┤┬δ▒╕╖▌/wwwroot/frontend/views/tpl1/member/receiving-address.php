<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title><?= WEB_TITLE ?> | 商城收货地址设置</title>
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
	<link href="/tpl/css/mui.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/tpl//css/own.css">
	<link rel="stylesheet" href="/tpl//css/public.css">
	<link rel="stylesheet" href="/tpl//css/fixpass.css">
	
</head>
<body>
<header class="mui-bar mui-bar-nav own-main-background-color">
	<span onclick="javascript :history.go(-1);" class="back mui-icon mui-icon-left-nav mui-pull-left"></span>
	<h1 class="mui-title">商城收货地址设置</h1>
</header>
<div class="mui-content" id="alipay">
	<div class="input" style="margin-bottom:0.5rem">
        <label for="name">姓名</label><input type="text" name="name" id="name" placeholder="请输入您姓名" value="<?= $model->name?>">
	</div>
    <div class="input" style="margin-bottom:0.5rem">
        <label for="phone">电话号码</label>
        <input type="text" name="phone" id="phone" placeholder="请输入您的电话号码" value="<?= empty($model->phone) ? Yii::$app->session->get('username') : $model->phone?>">
    </div>
    <div class="input" style="margin-bottom:0.5rem">
        <label for="address">收货地址</label><input type="text" name="address" id="address" placeholder="请输入您的收货地址" value="<?= $model->address?>">
    </div>
	<button type="button" class="post">提交</button>
</div>
<script src="/tpl//js/mui.min.js"></script>
<script src="/tpl//js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl//js/libs/ajax.js" charset="utf-8"></script>
<script src="/tpl//js/sub/alipay.js" charset="utf-8"></script>
<script src="/tpl//js/function.js" charset="utf-8"></script>
<script>
    var url = "<?= \yii\helpers\Url::to(['receiving-address']) ?>";
    var token = "<?= \Yii::$app->getRequest()->getCsrfToken() ?>";
    $('.post').click(function () {
        var name = $('#name').val();
        var phone = $('#phone').val();
        var address = $('#address').val();

        if(name == '' || phone == '' || address == ''){
            mui.alert('请将信息填写完整');return;
        }

        var data = {
            '_csrf-frontend': token,
            'ReceivingAddress[name]' : name,
            'ReceivingAddress[phone]': phone,
            'ReceivingAddress[address]': address
        };

        $.post(url, data, function (data) {
            mui.alert(data.message);
        }, 'json');
    });
</script>
</body>
</html>