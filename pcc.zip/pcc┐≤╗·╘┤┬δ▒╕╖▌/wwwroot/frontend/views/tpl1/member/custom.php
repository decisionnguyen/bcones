<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title><?= WEB_TITLE ?> | 客服中心</title>
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
	<link href="/tpl/css/mui.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/tpl/css/own.css">
	<link rel="stylesheet" href="/tpl/css/public.css">
	<link rel="stylesheet" href="/tpl/css/messinfo.css">
	<style>
		.mul>li{
			margin-top: 20px;
		}
		.main{
			position: fixed;
			display: flex;
			width: 100%;
			height: 100%;
			padding: 0;
		}
		#messageinfo{
			flex: 1;
			height: 100%;
			position: relative;
		}
		.kefu>p{
			margin: 2px 0;
		}
	</style>
</head>
<body>
	<div class="main">
		<header class="mui-bar mui-bar-nav own-main-background-color" style="position: static;">
			<span onClick="javascript :history.go(-1);" class="back mui-icon mui-icon-left-nav mui-pull-left"></span>
			<h1 class="mui-title">客服中心</h1>
		</header>
		<div class="" style="padding-top:.4rem" id="messageinfo">
			<div class="mui-scroll-wrapper">
				<div class="mui-scroll">
					<ul class="mul">
                       						
						
						<!--<li>
							<p>官方微信公众号: WX888888</p>
							<br>
							<img src="/tpl/img/gzh1.jpg" alt="" width="180px">
						</li>-->
						<li>
							<p>官方会员QQ群: 593045564</p>
							<br>
							<img src="/tpl/img/qq1.jpg" alt="" width="180px">
						</li>
						<li>
							<p>官方微信客服: q15721404743</p>
							<br>
							<img src="/tpl/img/wx1.jpg" alt="" width="180px">
						</li>
						<!--<li class="kefu">
							<p>官方客服QQ：（验证：会员）</p>
							<p>官方客服QQ：（验证：会员）</p>
						</li>
						<li>
							<p>CGC官方会员QQ群：</p>
							<p>会员①群：100458455(满)</p>
							<p>会员②群：147540151(满)</p>
							<p>会员③群： 99154874(满)</p>
							<p>会员⑥群：559081034(满)</p>
							<p>会员⑦群：689718959(满)</p>
							<p>会员⑧群：446507562(满)</p>
							<p>会员⑨群：496300434(满)</p>
							<p>会员⑩群：700592032(满)</p>
							
						</li>
                        <br>
                        <img src="/tpl/img/kf1.jpg" alt="" style="width: 300px; height: 300px;"-->
                        <br>
						<br>
						<br>
						<br>
						<br>
					</ul>
				</div>
			</div>
		</div>
	</div>


<script src="/tpl/js/mui.min.js"></script>
<script src="/tpl/js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl/js/libs/vue.min.js" charset="utf-8"></script>
<script src="/tpl/js/function.js" charset="utf-8"></script>
<script></script>
</body>
</html>