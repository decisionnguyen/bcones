<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title><?= WEB_TITLE ?> | 系统设置</title>
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
	<link href="/tpl/css/mui.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/tpl/css/own.css">
	<link rel="stylesheet" href="/tpl/css/public.css">
	<link rel="stylesheet" href="/tpl/css/notice.css">
	
</head>
<body>
<header class="mui-bar mui-bar-nav own-main-background-color" style="position: static;">
	<span onClick="javascript :history.go(-1);" class="back mui-icon mui-icon-left-nav mui-pull-left"></span>
	<h1 class="mui-title">系统设置</h1>
</header>
<div class="mui-content" id="#setting">
	<ul class="lists">
        
		
		<li><a>
			<div class="left"><b>平台制度（见公众号）</b></div>
			<div class="right"><i class="iconfont">&#xe603;</i></div>
		</a></li>
		<li><a>
			<div class="left"><b>推广奖励（见公众号）</b></div>
			<div class="right"><i class="iconfont">&#xe603;</i></div>
		</a></li>
		<li><a>
			<div class="left"><b>交易流程（见公众号）</b></div>
			<div class="right"><i class="iconfont">&#xe603;</i></div>
		</a></li>
		<li><a>
			<div class="left"><b>微信号</b></div>
			<div class="right">
				<div class="none">q15721404743</div>
			</div>
		</a></li>
		<li class="version"><a>
			<div class="left"><b>当前版本</b></div>
			<div class="right">
				<div class="none">1.1.2</div>
			</div>
		</a></li>
		<li style="border:none" onClick="location.href='<?= \yii\helpers\Url::to(['out'])?>'">
			<button type="button" id="clear" class="mui-btn mui-btn-primary mui-btn-block">退出程序</button>
		</li>
	</ul>
</div>
<script src="/tpl/js/mui.min.js"></script>
<script src="/tpl/js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl/js/sub/setting.js" charset="utf-8"></script>
<script src="/tpl/js/function.js" charset="utf-8"></script>
</body>
</html>