<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <title><?= WEB_TITLE ?> | 主控板</title>
    <link href="/tpl/css/mui.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/tpl/css/own.css">
    <link rel="stylesheet" href="/tpl/css/public.css">
    <link rel="stylesheet" href="/tpl/css/index.css">
    <link rel="stylesheet" href="/tpl/css/mine.css">

</head>
<body>
<div class="main">
    <header class="head own-main-background-color">
        <h1 id="nav-title" class="mui-title">玩家中心</h1>
    </header>
    <div class="content mui-content">
        <div class="mui-scroll-wrapper">
            <div class="mui-scroll" style="padding: 15px;">
                <div class="topbox">
                    <div class="headimg">
                        <a href="#" id="person" style="background: url(/tpl/img/logo.png);background-size: cover;">
                            <img id="myimg">
                        </a>
                    </div>
                    <div class="toptext">
                        <p>玩家ID：<?= $data['id'] ?></p>
                        <p>等级：<?= $member->getLevelName($data['level']) ?></p>
                    </div>
                    <?php if ($data['auth'] == 1) { ?>
                        
					    <a class="norenzheng" href="<?= \yii\helpers\Url::to(['au']) ?>" style="color:#666">待激活</a>
                    <?php } else { ?>
                        <a class="renzheng" href="<?= \yii\helpers\Url::to() ?>"
                           style="color:#00b738">已认证</a>
                    <?php } ?>

                    <ul class="topbtnbox">
                        <li><a href="<?= \yii\helpers\Url::to(['notice']) ?>" class="iconfont" id="message"
                               data-title="消息通知">&#xe614;</a>
                            <?php if ($messageTotal > 0): ?>
                                <div class="redcircle"></div>
                            <?php endif; ?>
                        </li>
                        <li><a href="<?= \yii\helpers\Url::to(['setting']) ?>" class="iconfont" id="setting"
                               data-title="设置">&#xe726;</a>
                        </li>
                    </ul>
                </div>
                <div class="numberbox"><p>资产总额 </p>
				
                    <div v-text="vrcToTal" style="font-size: 40px;"><?= $data['money'] ?>
                    </div>
					
                    <ul style="padding: 0.2rem;float:left;width:100%">
                        <!--li><span class="iconfont" id="keyong">&#xe622;</span><span>可用<?= MONEY_NAME ?>
                                ：<?= $data['money'] ?></span>
								</li-->
							
                        <li style="color:white;margin-left: 5%;width:70%">
                        <span class="iconfont" id="dongjie">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#xe701;</span>正在交易<?= MONEY_NAME ?>：<?= number_format($s, 5) ?>
                     </li>
					 
						<li style="width: 30%"><span class="renzheng sign" style="color:#00b738">签到</span></li>
                    </ul>
					
                </div>
                <ul class="gongnengbox">
                    <li>
                        <a href="<?= \yii\helpers\Url::to(['message']) ?>" data-title="玩家信息">
                            <div class="icon"><i class="smallicon1"></i></div>
                            <span>玩家信息</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= \yii\helpers\Url::to(['money-log']) ?>" data-title="个人账单">
                            <div class="icon"><i class="smallicon2"></i></div>
                            <span>个人账单</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= \yii\helpers\Url::to(['custom']) ?>" data-title="客服中心">
                            <div class="icon"><i class="smallicon4"></i></div>
                            <span>客服中心</span>
                        </a>
                    </li>
                    <li id="shop">
                        <a href="<?= \yii\helpers\Url::to(['shop/index']) ?>" data-title="eBay商城">
                            <div class="icon"><i class="smallicon5"></i></div>
                            <span>契约商城</span>
                        </a>
                    </li>
					<li>
                        <a href="<?= \yii\helpers\Url::to(['ab']) ?>" data-title="最新公告">
                            <div class="icon"><i class="smallicon6"></i></div>
                            <span>最新公告</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= \yii\helpers\Url::to(['spread']) ?>" data-title="平台推广">
                            <div class="icon"><i class="smallicon3"></i></div>
                            <span>平台推广</span>
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </div>

    <?php include_once './tpl/nav.php' ?>
</div>

<script src="/tpl/js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl/js/mui.min.js"></script>
<script src="/tpl/js/function.js" charset="utf-8"></script>
<script>
    var sgin_url = "<?= \yii\helpers\Url::to(['sign']) ?>";
    $('.sign').click(function () {
        $.get(sgin_url, {}, function (data) {
            mui.alert(data.message);
        }, 'json');
        return false;
    });
    mui("#game").on("tap", "a", function () {
        mui.alert('对接中');
    });
</script>
</body>
</html>