<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <title><?= WEB_TITLE ?> | 确认订单</title>
    <link rel="stylesheet" href="/tpl/css/mui.min.css">
    <link rel="stylesheet" href="/tpl/css/public.css">
    <link rel="stylesheet" href="/tpl/css/index.css">
    <link rel="stylesheet" href="/tpl/css/jishi.css">
    <link rel="stylesheet" href="/tpl//css/real_name.css">
    <style>
        .show{
            margin-bottom: 0.3rem;
            border: none !important;
        }
        .add_address {
            height: .68rem;
            outline: 0;
            border: none;
            padding: 0;
            font-size: .24rem;
            color: #fff;
            background: #02D2F5;
            text-align: center;
        }
    </style>
</head>
<body class="own-gray-color">
<div class="main">
    <header class="mui-bar mui-bar-nav own-main-background-color">
        <span onclick="javascript :history.go(-1);" class="back mui-icon mui-icon-left-nav mui-pull-left"></span>
        <h1 id="nav-title" class="mui-title">确认订单</h1>
    </header>

    <div class="content jishi">
        <div class="mui-scroll-wrapper">
            <div class="mui-scroll" style="padding:.2rem">
                <div class="show">
                    <div class="myinfo">
                        <p style="text-align: left">商品：<?= $goods->name?></p>
                    </div>
                    <div class="myinfo">
                        <p style="text-align: left">
                            价格：<?= $goods->price?>&nbsp;<?= MONEY_NAME ?>
                        </p>
                    </div>
                </div>
                <div class="show">
                    <?php if(!$r_address){ ?>
                        <a href="<?= \yii\helpers\Url::to(['member/receiving-address']) ?>" class="add_address" style="padding: .1rem 1rem;display: block;margin:.5rem auto;color: #fff">新增地址</a>
                    <?php }else{?>
                        <div class="myinfo">
                            <p style="text-align: left">收货人：<?=$r_address->name?></p>
                        </div>
                        <div class="myinfo">
                            <p style="text-align: left">电话：<?=$r_address->phone?></p>
                        </div>
                        <div class="myinfo">
                            <p style="text-align: left">详细地址：<?=$r_address->address?></p>
                        </div>
                        <div class="myinfo">
                            <a href="<?= \yii\helpers\Url::to(['member/receiving-address']) ?>" class="add_address" style="padding: .1rem 1rem;display: block;margin:.5rem auto;color: #fff">修改地址</a>
                        </div>

                    <?php }?>
                </div>
                <div class="show" style="">
                    <textarea placeholder="备注" row="5" id="remarks"></textarea>
                </div>
            </div>
        </div>
    </div>
    <div class="footer mui-bar mui-bar-tab my-bar">
        <a class="mui-tab-item mui-active" href="javascript:void(0)" id="to-buy">
            <span class="mui-icon iconfont">&#xe601;</span>
            <span class="mui-tab-label">立即支付</span>
        </a>
    </div>
</div>
</body>
</html>
<script src="/tpl/js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl/js/mui.min.js" charset="UTF-8"></script>
<script src="/tpl/js/function.js" charset="utf-8"></script>
<script>
    
    var buy_url = "<?= \yii\helpers\Url::to(['shop/order']) ?>";
	
	document.getElementById('to-buy').addEventListener('tap', function(){
		 var gid = <?=$goods->id?>;
			var remarks = $("#remarks").val();
			var data = {
				gid: gid,
				remarks: remarks,
				'_csrf-frontend': "<?= \Yii::$app->getRequest()->getCsrfToken() ?>"
			};
			$.post(buy_url, data, function (response) {
				mui.alert(response.message, function () {
					if(typeof(response.r) != 'undefined'){
						window.location.href = response.r;
					}
				});
			}, 'json');
	});
       
</script>