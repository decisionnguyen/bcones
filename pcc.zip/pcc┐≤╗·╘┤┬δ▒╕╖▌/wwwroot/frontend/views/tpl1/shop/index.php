<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <title><?= WEB_TITLE ?> | 契约商城</title>
    <link rel="stylesheet" href="/tpl/css/mui.min.css">
    <link rel="stylesheet" href="/tpl/css/public.css">
    <link rel="stylesheet" href="/tpl/css/index.css">
    <link rel="stylesheet" href="/tpl/css/jishi.css">
</head>
<body class="own-gray-color">
<div class="main">
    <header class="mui-bar mui-bar-nav own-main-background-color">
        <span onclick="javascript :history.go(-1);" class="back mui-icon mui-icon-left-nav mui-pull-left"></span>
        <h1 id="nav-title" class="mui-title">契约商城</h1>
    </header>

    <div class="content jishi">
        <div class="mui-scroll-wrapper">
            <div class="mui-scroll">
                <div class="" id="jishi">
                    <ul class="jsitems">
                        <?php foreach ($list as $model){ ?>
                        <li>
                            <div class="jsleft"><img src="<?= \yii\helpers\Json::decode($model->pic_list)[0]?>"></div>
                            <div class="jsmiddle">
                                <h2><?= $model->name?></h2>
                                <p>售价：<?= $model->price?>&nbsp;<?= MONEY_NAME ?></p>
                                <p>库存：<?= $model->stock?></p>
                            </div>
                            <div class="jsright">
                                <a href="<?= Yii::$app->urlManager->createUrl(['shop/detail', 'id'=>$model->id])?>" class="buybtn" style="color: #fff;width: 1.8rem;">
                                    <i class="iconfont">&#xe601;</i>立即购买
                                </a>
                            </div>
                        </li>
                        <?php }?>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <div class="footer mui-bar mui-bar-tab my-bar">
        <a class="mui-tab-item" href="<?= \yii\helpers\Url::to(['shop/order-list']) ?>">
            <span class="mui-icon iconfont">&#xe601;</span>
            <span class="mui-tab-label">我的订单</span>
        </a>
        <a class="mui-tab-item mui-active" href="<?= \yii\helpers\Url::to(['member/index']) ?>">
            <span class="mui-icon iconfont">&#xe60a;</span>
            <span class="mui-tab-label">返回首页</span>
        </a>
    </div>
</div>
</body>
<script src="/tpl/js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl/js/mui.min.js" charset="UTF-8"></script>
<script src="/tpl/js/function.js" charset="utf-8"></script>
</html>