<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <title><?= WEB_TITLE ?> | 我的订单</title>
    <link rel="stylesheet" href="/tpl/css/mui.min.css">
    <link rel="stylesheet" href="/tpl/css/public.css">
    <link rel="stylesheet" href="/tpl/css/index.css">
    <link rel="stylesheet" href="/tpl/css/jishi.css">
</head>
<body class="own-gray-color">
<div class="main">
    <header class="mui-bar mui-bar-nav own-main-background-color">
        <span onclick="javascript :history.go(-1);" class="back mui-icon mui-icon-left-nav mui-pull-left"></span>
        <h1 id="nav-title" class="mui-title">我的订单</h1>
    </header>

    <div class="content jishi">
        <div class="mui-scroll-wrapper">
            <div class="mui-scroll">
                <div class="" id="jishi">
                    <ul class="jsitems">
                        <?php foreach ($list as $model){ ?>
                        <li>
                            <div class="jsmiddle">
                                <p>系统单号：<?= $model->order?></p>
                                <p>支付金额：<?= $model->money?>&nbsp;<?= MONEY_NAME ?></p>
								<p>快递单号：<?= $model->express_order?></p>
                                <p>状态：<?= (new \common\models\GoodsOrder())->getStatusText($model->status)?></p>
                            </div>
                        </li>
                        <?php }?>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <div class="footer mui-bar mui-bar-tab my-bar">
        <a class="mui-tab-item" href="<?= \yii\helpers\Url::to(['shop/index']) ?>">
            <span class="mui-icon iconfont">&#xe601;</span>
            <span class="mui-tab-label">返回商城</span>
        </a>
        <a class="mui-tab-item mui-active" href="<?= \yii\helpers\Url::to(['member/index']) ?>">
            <span class="mui-icon iconfont">&#xe60a;</span>
            <span class="mui-tab-label">返回首页</span>
        </a>
    </div>
</div>
</body>
<script src="/tpl/js/libs/jquery.min.js" charset="utf-8"></script>
<script src="/tpl/js/mui.min.js" charset="UTF-8"></script>
<script src="/tpl/js/function.js" charset="utf-8"></script>
</html>