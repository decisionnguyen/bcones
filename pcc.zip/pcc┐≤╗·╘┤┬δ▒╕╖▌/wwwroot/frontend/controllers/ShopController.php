<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 2018/4/20
 * Time: 21:06
 */

namespace frontend\controllers;


use common\models\Goods;
use common\models\GoodsOrder;
use common\models\Member;
use common\models\MoneyLog;
use common\models\ReceivingAddress;
use yii\helpers\Json;

class ShopController extends CommonController
{

    public function actionIndex()
    {
        $list = Goods::find()->orderBy('create_time desc')->all();

        return $this->render('index', ['list'=>$list]);
    }

    public function actionDetail()
    {
        $id = \Yii::$app->request->get('id');
        $goods = Goods::find()->where(['id'=>$id])->one();

        return $this->render('detail', ['goods'=>$goods]);
    }

    public function actionBuy()
    {
        $id = \Yii::$app->request->get('id');
        $goods = Goods::find()->where(['id'=>$id])->one();
        if(!$goods){
            $redic_url = \Yii::$app->urlManager->createUrl('shop/index');
            return $this->renderContent('<script>alert("数据异常！");window.location.href="'.$redic_url.'";</script>');
        }
        $uid = \Yii::$app->session->get('uid');
        $r_address = ReceivingAddress::find()->where(['user_id'=>$uid])->one();

        return $this->render('buy', ['goods'=>$goods, 'r_address'=>$r_address]);
    }

    public function actionOrder()
    {
        if(\Yii::$app->request->isAjax){
            $gid = \Yii::$app->request->post('gid');
            $uid = \Yii::$app->session->get('uid');
            $goods = Goods::find()->where(['id'=>$gid])->one();

            if(!$goods){
                return $this->asJson(['message'=>'数据异常！']);
            }

            if($goods->stock < 1){
                return $this->asJson(['message'=>'暂时没库存了哦~']);
            }

            $goods->stock -= 1;
            $member = new Member();
            $member_array = $member->getUserInfo($uid);

            if($member_array['money'] < $goods->price){
                return $this->asJson(['message'=>'余额不足！']);
            }

            $address = ReceivingAddress::find()->where(['user_id'=>$uid])->orderBy('id desc')->asArray()->one();

            $remarks = \Yii::$app->request->post('remarks');
            $goods_order = new GoodsOrder();
            $goods_order->user_id = $uid;
            $goods_order->goods_id = $gid;
            $goods_order->goods_name = $goods->name;
            $goods_order->money = $goods->price;
            $goods_order->order = date('YmdHis').time().rand();
            $goods_order->address = Json::encode($address);
            $goods_order->remarks = $remarks;

            $money_log = new MoneyLog();
            $money_log->moneyChange($uid, 10, 0-abs($goods->price), '购买商品-'.$goods->name);

            $goods_order->status = GoodsOrder::STATUS_ALREADY_PAID;

            $goods_order->create_time = date('Y-m-d H:i:s');
            $goods_order->update_time = date('Y-m-d H:i:s');

            if($goods_order->save() && $goods->save()){
                return $this->asJson(['message'=>'购买成功！', 'r'=>\Yii::$app->urlManager->createUrl('shop/order-list')]);
            }else{
                return $this->asJson(['message'=>'购买失败！']);
            }
        }
    }

    public function actionOrderList()
    {
        $uid = \Yii::$app->session->get('uid');

        $list = GoodsOrder::find()->where(['user_id'=>$uid])->orderBy('update_time desc')->all();

        return $this->render('order-list', ['list'=>$list]);
    }
}