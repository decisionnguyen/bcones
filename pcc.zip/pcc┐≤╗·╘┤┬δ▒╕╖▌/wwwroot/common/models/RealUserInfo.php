<?php
namespace common\models;

use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $uid
 * @property string $realname
 * @property string $idcard
 * @property string $mobile
 * @property string $bankcard
 * @property string $add_time
 * @author Administrator
 *
 */
class RealUserInfo extends ActiveRecord
{
    public static function tableName()
    {
        return "{{%real_user_info}}";
    }
}