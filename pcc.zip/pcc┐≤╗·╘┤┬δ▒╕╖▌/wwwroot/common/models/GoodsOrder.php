<?php

namespace common\models;


use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;

class GoodsOrder extends ActiveRecord
{
    const STATUS_UNPAID = 'UNPAID';
    const STATUS_ALREADY_PAID = 'ALREADY_PAID';
    const STATUS_ALREADY_SHIPPED = 'ALREADY_SHIPPED';
    const STATUS_DONE = 'DONE';

    public static function tableName()
    {
        return "{{%goods_order}}";
    }

    public function rules()
    {
        return [

        ];
    }

    public function getStatusArray()
    {
        return [
            self::STATUS_UNPAID => '未付款',
            self::STATUS_ALREADY_PAID => '已付款',
            self::STATUS_ALREADY_SHIPPED => '已发货',
            self::STATUS_DONE => '已完成',
        ];
    }

    public function getStatusText($status)
    {
        $status_array = $this->getStatusArray();
        return ArrayHelper::getValue($status_array, $status, '未知状态');
    }
}