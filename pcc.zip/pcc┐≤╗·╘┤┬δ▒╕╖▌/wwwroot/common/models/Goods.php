<?php

namespace common\models;


use yii\db\ActiveRecord;

class Goods extends ActiveRecord
{
    public static function tableName()
    {
        return "{{%goods}}";
    }

    public function rules()
    {
        return [

        ];
    }
}