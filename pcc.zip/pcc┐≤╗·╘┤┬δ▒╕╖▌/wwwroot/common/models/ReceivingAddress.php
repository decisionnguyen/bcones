<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 2018/4/20
 * Time: 21:29
 */

namespace common\models;


use yii\db\ActiveRecord;

class ReceivingAddress extends ActiveRecord
{
    public static function tableName()
    {
        return "{{%receiving_address}}";
    }

    public function rules()
    {
        return [
            [['name', 'phone', 'address'], 'required', 'message' => '请将信息填写完整'],
        ];
    }
}