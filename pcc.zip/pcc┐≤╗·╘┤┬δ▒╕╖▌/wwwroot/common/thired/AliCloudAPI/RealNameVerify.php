<?php
namespace common\thired\AliCloudAPI;

/**
 * 银行卡四要素验证
 * @author Administrator
 *
 */
class RealNameVerify
{
    /**
     * 银行卡号
     * @var string
     */
    public $bankcard = '';
    
    /**
     * 身份证号
     * @var string
     */
    public $idcard = '';
    
    /**
     * 手机号
     * @var string
     */
    public $mobile = '';
    
    /**
     * 姓名
     * @var string
     */
    public $realname = '';
    
    
    protected $gateway = 'http://jisubank4.market.alicloudapi.com/bankcardverify4/verify';
    
    protected $appcode = '197249e615d944d2b38b2fe2e644b4dd';
    
    public function __construct($_bankcard, $_idcard, $_mobile, $_realname)
    {
        $this->bankcard = $_bankcard;
        $this->idcard = $_idcard;
        $this->mobile = $_mobile;
        $this->realname = $_realname;
        
    }
    
    public function verify()
    {
        $response = $this->send();
        if($response['status'] != '0'){
            return $response['msg'];
        }
        
        if($response['result']['verifystatus'] == '1'){
            return $response['result']['verifymsg'];
        }
        
        return true;
    }
    
    protected function send()
    {
        $method = "GET";
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $this->appcode);
        $querys = [
            'bankcard' => $this->bankcard,
            'idcard' => $this->idcard,
            'mobile' => $this->mobile,
            'realname' => $this->realname,
        ];
        
        $querys = http_build_query($querys);
        
        $bodys = "";
        $url = $this->gateway . '?' . $querys;
        
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        if (1 == strpos("$".$url, "https://"))
        {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $response = curl_exec($curl);
        curl_close($curl);
		
        return json_decode($response, true);
    }
}