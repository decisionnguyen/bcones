<?php

namespace backend\controllers;


use common\models\GoodsOrder;
use yii\data\Pagination;
use yii\helpers\Json;

class GoodsOrderController extends CommonController
{
    public function actionIndex()
    {

        $t_count = GoodsOrder::find()->orderBy('id desc')->count();

        $pagination = new Pagination(['totalCount' => $t_count, 'pageSize' => 20]);

        $list = GoodsOrder::find()->orderBy('id desc')->offset($pagination->offset)->limit($pagination->limit)->all();

        return $this->render('list', ['list'=>$list, 'pagination'=>$pagination]);
    }

    public function actionView()
    {
        $id = \Yii::$app->request->get('id', 0);
        $order = GoodsOrder::find()->where(['id'=>$id])->one();
        $order->address = Json::decode($order->address);
        return $this->render('view', ['order'=>$order]);
    }

    public function actionDelete()
    {
        $id = \Yii::$app->request->get('id', 0);
        if(GoodsOrder::deleteAll(['id'=>$id])){
            $redic_url = \Yii::$app->urlManager->createUrl('goods-order/index');
            return $this->renderContent('<script>alert("删除成功！");window.location.href="'.$redic_url.'";</script>');
        }else{
            return $this->renderContent('<script>alert("删除失败！");history.go(-1);</script>');
        }
    }

    public function actionUpdate()
    {
        $id = \Yii::$app->request->post('id', 0);
        $order = GoodsOrder::find()->where(['id'=>$id])->one();
        if(!$order){
            return $this->renderContent('<script>alert("数据异常！");history.go(-1);</script>');
        }

        $status =  \Yii::$app->request->post('status');
        $express_order =  \Yii::$app->request->post('express_order');
        $order->status = $status;
        $order->express_order = $express_order;

        if($order->save()){
            return $this->renderContent('<script>alert("操作成功！");history.go(-1);</script>');
        }
    }
}