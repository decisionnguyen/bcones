<?php

namespace backend\controllers;


use common\models\Goods;
use OSS\OssClient;
use yii\data\Pagination;
use yii\helpers\Json;
use yii\web\UploadedFile;

include 'AliOSS/aliyun-oss-php-sdk-2.3.0.phar';

class GoodsController extends CommonController
{

    public function actionIndex()
    {
        $t_count = Goods::find()->orderBy('id desc')->count();

        $pagination = new Pagination(['totalCount' => $t_count, 'pageSize' => 20]);

        $list = Goods::find()->orderBy('id desc')->offset($pagination->offset)->limit($pagination->limit)->all();

        return $this->render('list', ['list'=>$list, 'pagination'=>$pagination]);
    }

    public function actionAdd()
    {
        if(\Yii::$app->request->isPost){
            $model = new Goods();
            $model->name = \Yii::$app->request->post('name');
            $model->price = \Yii::$app->request->post('price');
            $model->stock = \Yii::$app->request->post('stock');

            // {{ 上传图片
            $upload = UploadedFile::getInstanceByName('pic');
            $root_path = 'uploads/' . date('ymd', time());
            if (!is_dir($root_path)) {
                mkdir($root_path, 0777, true);
            }
            $randName = md5(microtime());   //生成随机文件名
            $uploadPath = $root_path . '/' . $randName . '.' . $upload->extension;  //设置保存路径， 为 backend\web\uploads
            $upload->saveAs($uploadPath);  //保存文件

            // 上传OSS
            //$ossClient = new OssClient('LTAIJigUpEBxY6qa', 'UY9OueaNXpsNgY5GhDZ24rBJ7lo7PY', 'oss-cn-shanghai.aliyuncs.com');
            //$ossClient->uploadFile('fenghuangc9', $uploadPath, realpath($uploadPath));
            //$full_url = 'http://fenghuangc9.oss-cn-shanghai.aliyuncs.com/'.$uploadPath;

            $full_url = 'http://201842906.code.com/'.$uploadPath;
            $model->pic_list = Json::encode([$full_url]);
            $goods_version = \Yii::$app->request->post('goods_version');
            if($goods_version != null){
                $model->goods_version = Json::encode(\Yii::$app->request->post('goods_version'));
            }

            $model->info = \Yii::$app->request->post('info');

            $model->create_time = date('Y-m-d H:i:s');
            $model->update_time = date('Y-m-d H:i:s');

            if($model->save()){
                $redic_url = \Yii::$app->urlManager->createUrl('goods/index');
                return $this->renderContent('<script>alert("增加成功！");window.location.href="'.$redic_url.'";</script>');
            }else{
                return $this->renderContent('<script>alert("增加失败！");history.go(-1);</script>');
            }
        }

        return $this->render('add');
    }

    public function actionDelete()
    {
        $id = \Yii::$app->request->get('id', 0);
        if(Goods::deleteAll(['id'=>$id])){
            $redic_url = \Yii::$app->urlManager->createUrl('goods/index');
            return $this->renderContent('<script>alert("删除成功！");window.location.href="'.$redic_url.'";</script>');
        }else{
            return $this->renderContent('<script>alert("删除失败！");history.go(-1);</script>');
        }
    }

    public function actionUpdate()
    {
        $id = \Yii::$app->request->get('id', 0);
        $goods = Goods::find()->where(['id'=>$id])->one();

        if(\Yii::$app->request->isPost){

            $goods->name = \Yii::$app->request->post('name');
            $goods->price = \Yii::$app->request->post('price');
            $goods->stock = \Yii::$app->request->post('stock');
            $goods->info = \Yii::$app->request->post('info');
            if($_FILES['pic']['error'] == 0){
                // {{ 上传图片
                $upload = UploadedFile::getInstanceByName('pic');
                $root_path = 'uploads/' . date('ymd', time());
                if (!is_dir($root_path)) {
                    mkdir($root_path, 0777, true);
                }
                $randName = md5(microtime());   //生成随机文件名
                $uploadPath = $root_path . '/' . $randName . '.' . $upload->extension;  //设置保存路径， 为 backend\web\uploads
                $upload->saveAs($uploadPath);  //保存文件

                // 上传OSS
               // $ossClient = new OssClient('LTAIJigUpEBxY6qa', 'UY9OueaNXpsNgY5GhDZ24rBJ7lo7PY', 'oss-cn-shanghai.aliyuncs.com');
				//$ossClient->uploadFile('fenghuangc9', $uploadPath, realpath($uploadPath));
				//$full_url = 'http://fenghuangc9.oss-cn-shanghai.aliyuncs.com/'.$uploadPath;
                  $full_url = 'http://201842906.code.com/'.$uploadPath;
                $goods->pic_list = Json::encode([$full_url]);
            }

            $goods->update_time = date('Y-m-d H:i:s');

            if($goods->save()){
                $redic_url = \Yii::$app->urlManager->createUrl('goods/index');
                return $this->renderContent('<script>alert("修改成功！");window.location.href="'.$redic_url.'";</script>');
            }else{
                return $this->renderContent('<script>alert("修改失败！");history.go(-1);</script>');
            }

        }
        return $this->render('update', ['model'=>$goods]);
    }
}