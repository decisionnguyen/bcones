<div class="breadcrumbs" id="breadcrumbs">
    <ul class="breadcrumb">
        <li>
            <i class="icon-home home-icon"></i>
            <a href="<?= Yii::$app->urlManager->createUrl(['goods-order/index']) ?>">订单列表</a>
        </li>
        <li class="active">订单详情</li>
    </ul>
</div>
<style>
    .class1 {
        padding: 10px;
    }
</style>
<div class="page-content">
    <div class="row">
        <div class="col-md-6 class1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">订单信息</h3>
                </div>
                <div class="panel-body">
                    <p>订单号：<?= $order->order?></p>
                    <p>购买商品：<?= $order->goods_name?></p>
                    <p>支付金额：<?= $order->money?></p>
                    <p>快递单号：<?= $order->express_order?$order->express_order:'暂无记录'?></p>
                    <p>订单备注：<?= $order->remarks?></p>
                    <p>订单状态：<?= (new \common\models\GoodsOrder())->getStatusText($order->status) ?></p>
                    <p>下单时间：<?= $order->create_time?></p>
                    <p>更新时间：<?= $order->update_time?></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 class1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">订单操作</h3>
                </div>

                <div class="panel-body">
                    <form class="form-horizontal" action="<?= Yii::$app->urlManager->createUrl('goods-order/update')?>" method="post">
                        <input type="hidden" name="_csrf-backend" id="_crsf" value="<?=Yii::$app->request->csrfToken;?>">
                        <input type="hidden" name="id", value="<?=$order->id?>">
                        <div class="form-group col-md-12">
                            <label for="status">订单状态</label>
                            <select class="form-control" name="status" id="status">
                                <?php
                                $goods_order_model = new \common\models\GoodsOrder();
                                foreach ($goods_order_model->getStatusArray() as $k=>$v){?>
                                    <option value="<?=$k?>"><?=$v?></option>
                                <?php }?>
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="express_order">快递单号</label>
                            <input type="text" class="form-control" name="express_order" id="express_order" placeholder="请输入快递单号">
                        </div>
                        <button type="submit" class="btn btn-danger">修改订单</button>
                    </form>
                </div>

            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-md-6 class1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">收货信息</h3>
                </div>
                <div class="panel-body">
                    <p>收货人：<?= $order->address['name']?></p>
                    <p>联系电话：<?= $order->address['phone']?></p>
                    <p>详细地址：<?= $order->address['address']?></p>
                </div>
            </div>
        </div>
    </div>

</div>