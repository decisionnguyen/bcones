<div class="breadcrumbs" id="breadcrumbs">
    <ul class="breadcrumb">
        <li>
            <i class="icon-home home-icon"></i>
            <a href="#">首页</a>
        </li>
        <li class="active">控制台</li>
    </ul>
</div>
<style>
    .class1 {
        padding: 10px;
    }
</style>
<div class="page-content">
    <div class="row">
        <div class="col-md-4 class1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">会员总人数</h3>
                </div>
                <div class="panel-body">
                    <?php echo $member_all; ?>
                </div>
            </div>


        </div>

        <div class="col-md-4 class1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">矿机总台数（运行中）</h3>
                </div>
                <div class="panel-body">
                    <?php echo $product_count; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4 class1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">矿机总算力（运行中）</h3>
                </div>
                <div class="panel-body">
                    <?php echo $product_num; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4 class1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">虚拟币总量</h3>
                </div>
                <div class="panel-body">
                    <?php echo $money; ?>
                </div>
            </div>
        </div>

    </div>

    <!--制度说明开始
    <h3>制度说明</h3>
    <p>矿机收益</p>
    <p>
        10币购进迷你云矿机：0.167币/天，180天，每人限购10台 <br>
        50币购进小型云矿机：0.861币/天，180天，每人限购6台 <br>
        250币购进中型云矿机：4.445币/天，180天，每人限购4台<br>
        1250币购进大型云矿机：22.917币/天，180天，每人限购2台 <br>
        6250币购进巨型云矿机：118.056币/天，180天，每人限购1台
    </p>
    <br>
    <p>认证只需填写正确的证件号码和银行卡号（同一人）即可，无需上传任何照片。系统会自动比对真假，1-10分钟内即可完成，无需人工审核</p>
	<br>
	<p>建群奖励</p>
    直推十人，建微信群200人奖励如下：<br>
	官方客服考核评选，通过星级评比获得相应奖励，每月月底统一发放<br>
    一星群主每月奖励CAC币20枚<br>
    二星群主每月奖励CAC币30枚<br>
    三星群主每月奖励CAC币40枚<br>
	以上奖励由CAC平台交易手续费中产生，并每月按时发放<br>
    <br>
    <p>
        交易制度 <br>
        为了维护平台的正常运行，所有交易收取30%手续费 <br>
        交易方式：全网自动匹配双方交易和指定交易 <br>
		平台审核每一单交易，确保交易安全<br>
    </p>
    <br>
    <p>
        算力说明 <br>
        伞下每投资一个矿机为领导人提供算力。必须是运行中的矿机 <br>
        迷你：1算力 <br>
        小型：5算力 <br>
        中型：25算力 <br>
        大型：125算力 <br>
        巨型：625算力 <br>
    </p>
    <br>
    <p>
        动态收益 <br>
		1、普通会员：需有一台正常运转的矿机，享受一代直推5%收益 <br>
        2、烧伤制度：如果自己当天产出3个币，伞下单个某会员产出5个币，那么按照3个币的产出拿此会员领导奖 <br>
        3、团队奖励：<br>
        升级主管：要求矿池算力达到200T，直推30名普通会员 <br>
        奖励总收益155币的小型云矿机一台。<br>
        开启二代会员的1%收益 <br>
        <br>
        升级经理：要求矿池算力达到800T，直推三名主管 <br>
        奖励总收益800币的中型云矿机一台 <br>
        开启三代会员的2%收益 <br>
        <br>
        升级总监：要求矿池算力达到3200T，直推三名经理 <br>
        奖励总收益4125币的大型云矿机一台 <br>
        开启四代会员的3%收益 <br>
		
        <br>
        升级总裁：要求矿池算力达到12500T，直推三名总监 <br>
        奖励总收益21250币的巨型云矿机一台 <br>
        开启五代会员的4%收益 <br>
		
    </p>
    <br>
    <p>
        CAC开盘发行价1元/枚 <br>
        可挖掘总币量为1000万枚 <br>
        在总挖掘量达到500万枚后上交易所。
    </p>
    制度说明结束-->
   <!-- <br>
    <p>添加制度：用户每日签到送0.01CAC币</p>-->
    <!--p>锁仓制度：矿机每日收益的10%（后台配置参数）锁仓，锁仓币可用于购买消耗，后台可释放锁仓币进入可用币钱包</p-->
</div>