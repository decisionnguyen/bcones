<link href="umeditor/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
<div class="breadcrumbs" id="breadcrumbs">
    <script type="text/javascript">
        try {
            ace.settings.check('breadcrumbs', 'fixed')
        } catch (e) {
        }
    </script>
    <ul class="breadcrumb">
        <li>
            <i class="icon-home home-icon"></i>
            <a href="<?=Yii::$app->urlManager->createUrl(['goods/index'])?>">商品管理</a>
        </li>
        <li class="active">修改商品</li>
    </ul>
</div>
<h3 class="header smaller lighter grey" style="padding-left: 15px">
    <a href="<?=Yii::$app->urlManager->createUrl(['goods/index'])?>" class="btn btn-sm btn-danger">
        <i class="icon-reply icon-only"></i>
        返回列表
    </a>
</h3>

<div class="page-content">
    <form class="form-horizontal" method="post" enctype="multipart/form-data" role="form">
        <input type="hidden" name="_csrf-backend" id="_crsf" value="<?=Yii::$app->request->csrfToken;?>">
        <div class="form-group col-sm-12">
            <label class="col-sm-2 control-label">商品名字</label>
            <div class="col-sm-6">
                <input type="text" name="name" placeholder="请输入商品名字" class="form-control" value="<?= $model->name?>" required>
            </div>
        </div>
        <div class="form-group col-sm-12">
            <label class="col-sm-2 control-label">价格</label>
            <div class="col-sm-6">
                <input type="text" name="price" placeholder="请输入价格" class="form-control" value="<?= $model->price?>" required>
            </div>
        </div>
        <div class="form-group col-sm-12">
            <label class="col-sm-2 control-label">库存</label>
            <div class="col-sm-6">
                <input type="number" name="stock" placeholder="请输入库存" class="form-control" value="<?= $model->stock?>" required>
            </div>
        </div>
        <div class="form-group col-sm-12">
            <label class="col-sm-2 control-label">图片</label>
            <div class="col-sm-6">
                <input type="file" name="pic" placeholder="请输入选择图片" class="form-control">
            </div>
        </div>
<!--        <div class="form-group col-sm-12" id="goods_version">-->
<!--            <label class="col-sm-2 control-label">商品规格</label>-->
<!--            <div class="col-sm-6">-->
<!--                <button class="btn btn-sm btn-danger create_version" type="button">-->
<!--                    <i class="icon icon-plus"></i>-->
<!--                    添加规格-->
<!--                </button>-->
<!--            </div>-->
<!--        </div>-->
        <div class="form-group col-sm-12">
            <label class="col-sm-2 control-label">商品介绍</label>
            <div class="col-sm-6">
                <textarea class="form-control" name="info" id="myEditor" style="height:340px;"><?= $model->info?></textarea>
            </div>
        </div>
        <div class="form-group col-sm-12" style="margin-top: 20px">
            <label class="col-sm-2 control-label"></label>
            <div class="col-sm-5">
                <button type="submit" class="btn btn-sm btn-primary">保存</button>
            </div>
        </div>
    </form>
<!--    <div id="goods_version_template" style="display: none;">-->
<!--        <label class="col-sm-2 control-label">商品规格</label>-->
<!--        <div class="col-sm-6">-->
<!--            <input type="text" name="goods_version[@][name]" placeholder="请输入规格名字" class="form-control">-->
<!--            <input type="text" name="goods_version[@][price]" placeholder="请输入规格价格" class="form-control">-->
<!--        </div>-->
<!--    </div>-->
</div>
<script type="text/javascript" charset="utf-8" src="umeditor/umeditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="umeditor/umeditor.min.js"></script>
<script type="text/javascript" src="umeditor/lang/zh-cn/zh-cn.js"></script>
<script>

    var um = UM.getEditor('myEditor');

    // var version_count = 1;
    // $(document).delegate('.create_version', 'click', function () {
    //     var target = $('#goods_version_template');
    //     var html = target.html();
    //     html = html.replace(/@/g, 'item_'+version_count);
    //     $('#goods_version').after('<div class="form-group col-sm-12">'+html+'</div>');
    //     version_count++;
    // })
</script>
