<link href="/admin/css/foundation-datepicker.min.css" rel="stylesheet"/>
<link rel="stylesheet" href="/admin/assets/css/chosen.css"/>
<div class="breadcrumbs" id="breadcrumbs">
    <ul class="breadcrumb">
        <li>
            <i class="icon-home home-icon"></i>
            <a href="#">商城管理</a>
        </li>
        <li class="active">商品列表</li>
    </ul>
</div>
<h3 class="header smaller lighter grey" style="padding-left: 15px">
    <a href="<?= Yii::$app->urlManager->createUrl(['goods/add']) ?>" class="btn btn-sm btn-primary">
        <i class="icon-plus"></i>新增商品
    </a>
</h3>
<div class="page-content">
    <div class="table-responsive" style="margin-top: 35px">
        <table id="sample-table-2" class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th class="center">编号</th>
                <th class="center">名字</th>
                <th class="center">价格</th>
                <th class="center">库存</th>
                <th class="center">发布时间</th>
                <th class="center">修改时间</th>
                <th class="center">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($list as $v) { ?>
                <tr>
                    <td class="center"><?= $v->id ?></td>
                    <td class="center"><?= $v->name ?></td>
                    <td class="center"><?= $v->price ?></td>
                    <td class="center"><?= $v->stock ?></td>
                    <td class="center"><?= $v->create_time ?></td>
                    <td class="center"><?= $v->update_time ?></td>
                    <td class="center">
                        <a href="<?php echo \yii\helpers\Url::to(['update', 'id' => $v->id]); ?>">修改</a>
                        <a href="<?php echo \yii\helpers\Url::to(['delete', 'id' => $v->id]); ?>">删除</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <nav>
            <ul class="pagination pright">
                <?php echo \yii\widgets\LinkPager::widget(['pagination' => $pagination]); ?>
            </ul>
        </nav>

    </div>
    <ul class="pagination" style="float: right">

    </ul>
</div>
<script src="/admin/assets/js/chosen.jquery.min.js"></script>
<script src="/admin/js/dateTime/foundation-datepicker.js"></script>
<script src="/admin/js/dateTime/locales/foundation-datepicker.zh-CN.js"></script>


