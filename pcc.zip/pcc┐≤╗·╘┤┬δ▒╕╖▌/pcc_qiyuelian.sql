/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : pcc_qiyuelian

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-07-19 20:52:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `inv_admin`
-- ----------------------------
DROP TABLE IF EXISTS `inv_admin`;
CREATE TABLE `inv_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL,
  `passwd` char(32) NOT NULL,
  `login_time` int(11) DEFAULT NULL,
  `login_ip` char(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_admin
-- ----------------------------
INSERT INTO `inv_admin` VALUES ('1', 'PCCmanage', 'eb106053be1bdc8bae8bd6a39be36f94', '1531628226', '183.195.35.56');

-- ----------------------------
-- Table structure for `inv_config`
-- ----------------------------
DROP TABLE IF EXISTS `inv_config`;
CREATE TABLE `inv_config` (
  `name` char(50) NOT NULL,
  `key` char(50) NOT NULL,
  `value` char(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `order_by` tinyint(2) NOT NULL DEFAULT '1',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_config
-- ----------------------------
INSERT INTO `inv_config` VALUES ('动态奖1代（%）', 'd_1', '5', '1', '1', '1');
INSERT INTO `inv_config` VALUES ('动态奖2代（%）', 'd_2', '2', '1', '2', '1');
INSERT INTO `inv_config` VALUES ('动态奖3代（%）', 'd_3', '3', '1', '3', '1');
INSERT INTO `inv_config` VALUES ('动态奖4代（%）', 'd_4', '4', '1', '4', '1');
INSERT INTO `inv_config` VALUES ('动态奖5代（%）', 'd_5', '5', '1', '5', '1');
INSERT INTO `inv_config` VALUES ('升级一级矿工条件（算力;直推低一级矿工人数）自动开启动态2代', 's_1', '100;3', '1', '6', '1');
INSERT INTO `inv_config` VALUES ('升级一级矿工奖励小型矿机台数', 'j_1', '1', '1', '7', '1');
INSERT INTO `inv_config` VALUES ('升级二级矿工条件（算力;直推低一级矿工人数）自动开启动态3代', 's_2', '500;3', '1', '8', '1');
INSERT INTO `inv_config` VALUES ('升级二级矿工奖励中型矿机台数', 'j_2', '1', '1', '9', '1');
INSERT INTO `inv_config` VALUES ('升级三级矿工条件（算力;直推低一级矿工人数）自动开启动态4代', 's_3', '2500;3', '1', '10', '1');
INSERT INTO `inv_config` VALUES ('升级三级矿工奖励大型矿机台数', 'j_3', '1', '1', '11', '1');
INSERT INTO `inv_config` VALUES ('升级四级矿工条件（算力;直推低一级矿工人数）自动开启动态5代', 's_4', '12500;3', '1', '12', '1');
INSERT INTO `inv_config` VALUES ('升级四级矿工奖励巨型矿机台数', 'j_4', '1', '1', '13', '1');
INSERT INTO `inv_config` VALUES ('虚拟币建议单价(当前)', 'm_p', '0.16', '1', '14', '1');
INSERT INTO `inv_config` VALUES ('虚拟币单价每日上涨', 'm_p_r', '0.01', '1', '15', '1');
INSERT INTO `inv_config` VALUES ('点对点交易手续费（%）', 'd_t_d', '30', '1', '16', '1');
INSERT INTO `inv_config` VALUES ('挂单单价最小值', 'g_d_min', '1', '1', '17', '1');
INSERT INTO `inv_config` VALUES ('挂单单价最大值', 'g_d_max', '30', '1', '18', '1');
INSERT INTO `inv_config` VALUES ('挂单手续费（%）', 'g_d_d', '30', '1', '19', '1');
INSERT INTO `inv_config` VALUES ('每日签到送币', 'sign', '0.01', '1', '20', '1');
INSERT INTO `inv_config` VALUES ('矿机收益锁仓（%）', 'lock', '0', '1', '21', '1');

-- ----------------------------
-- Table structure for `inv_face_order`
-- ----------------------------
DROP TABLE IF EXISTS `inv_face_order`;
CREATE TABLE `inv_face_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `money` decimal(10,4) unsigned NOT NULL,
  `member_id` int(11) unsigned NOT NULL,
  `target_member_id` int(11) unsigned NOT NULL,
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1:等待确定交易，3.取消交易，2.交易成功',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  `rate_money` decimal(10,4) NOT NULL,
  `target_member_name` varchar(50) NOT NULL,
  `image` varchar(500) DEFAULT NULL,
  `finish_time` int(11) DEFAULT NULL,
  `pay_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_face_order
-- ----------------------------
INSERT INTO `inv_face_order` VALUES ('1', '0611124309923356', '200.0000', '5', '4', '1528692189', '5', '1528692538', '60.0000', '18121111885', null, null, null);
INSERT INTO `inv_face_order` VALUES ('2', '0611124918595444', '100.0000', '4', '5', '1528692558', '4', '0', '30.0000', '17551040815', 'http://pcc.one/uploads/180611/573-0b2315d6788ef0ef544a61c68bd6d2b4.jpg', '1528697922', '1528697129');
INSERT INTO `inv_face_order` VALUES ('3', '0611142024783853', '1000.0000', '4', '5', '1528698024', '4', '0', '300.0000', '17551040815', 'http://pcc.one/uploads/180611/125-772e35dfca98cbc847b90efe44e7e5f7.jpg', '1528698584', '1528698501');
INSERT INTO `inv_face_order` VALUES ('4', '0611192459332054', '100.0000', '4', '5', '1528716299', '4', '0', '30.0000', '17551040815', 'http://www.pcc.one/uploads/180611/647-13ac47bf40799647260180708804dd99.jpg', '1528716338', '1528716318');
INSERT INTO `inv_face_order` VALUES ('5', '0611193058678540', '1000.0000', '8', '4', '1528716658', '4', '0', '300.0000', '18121111885', 'http://www.pcc.one/uploads/180611/960-3df532e03b7763746236001ba7641412.jpg', '1528732545', '1528732532');
INSERT INTO `inv_face_order` VALUES ('6', '0611235615457054', '2000.0000', '4', '8', '1528732575', '4', '0', '600.0000', '13098888675', 'http://www.pcc.one/uploads/180612/492-e3009bb28ac1c6de153370751c8d2050.png', '1528792820', '1528792803');

-- ----------------------------
-- Table structure for `inv_goods`
-- ----------------------------
DROP TABLE IF EXISTS `inv_goods`;
CREATE TABLE `inv_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `pic_list` text,
  `goods_version` text,
  `info` longtext,
  `buy_condition` text,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_goods
-- ----------------------------
INSERT INTO `inv_goods` VALUES ('3', '话费充值', '100.00', '998', '[\"http://201842906.code.com/uploads/180502/47c25762d4c872cc5705f6aedfa1a1f9.jpg\"]', null, '<p>等比有货</p>', null, '2018-04-22 18:49:37', '2018-05-02 23:03:38');

-- ----------------------------
-- Table structure for `inv_goods_order`
-- ----------------------------
DROP TABLE IF EXISTS `inv_goods_order`;
CREATE TABLE `inv_goods_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `goods_id` int(11) DEFAULT NULL,
  `goods_name` varchar(255) DEFAULT NULL,
  `money` decimal(10,2) DEFAULT NULL,
  `order` varchar(255) DEFAULT NULL,
  `address` text,
  `express_order` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_goods_order
-- ----------------------------

-- ----------------------------
-- Table structure for `inv_member`
-- ----------------------------
DROP TABLE IF EXISTS `inv_member`;
CREATE TABLE `inv_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` char(15) NOT NULL,
  `p_id` int(11) DEFAULT NULL COMMENT '上级主键id',
  `passwd` char(32) NOT NULL,
  `charge_passwd` char(32) NOT NULL COMMENT '交易密码',
  `money` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` char(50) DEFAULT NULL,
  `login_time` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL COMMENT '1:正常 2:封号',
  `auth` tinyint(1) NOT NULL DEFAULT '1',
  `level` tinyint(2) NOT NULL DEFAULT '10',
  `name` char(255) DEFAULT NULL,
  `weixin` char(255) DEFAULT NULL,
  `zhifubao` char(255) DEFAULT NULL,
  `bank_name` char(255) DEFAULT NULL,
  `bank_card` char(255) DEFAULT NULL,
  `id_card` char(255) DEFAULT NULL,
  `bank_mobile` char(15) DEFAULT NULL,
  `eth_address` char(255) DEFAULT NULL,
  `team_num` int(11) NOT NULL DEFAULT '0',
  `team_count` int(11) NOT NULL DEFAULT '0',
  `rate_time` int(11) DEFAULT NULL,
  `s` tinyint(1) NOT NULL DEFAULT '1',
  `money_lock` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `free` tinyint(3) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `team_num` (`team_num`),
  KEY `team_money` (`team_count`),
  KEY `create_ip` (`create_ip`),
  KEY `id_card` (`id_card`)
) ENGINE=MyISAM AUTO_INCREMENT=25894 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_member
-- ----------------------------
INSERT INTO `inv_member` VALUES ('25889', '13761605266', '25888', '135b91583b294ea9831384de978b0331', '7d928f7a7e64b7e6240c068f5b290d6b', '53085.29240', '1528826341', '183.195.34.204', '1531627077', '1', '2', '0', '范有龙', '13761605266', '13761605266', null, '6222021001000037041', '362502198710160018', '13761605266', null, '1001', '2', '1531670399', '1', '0.00000', '2');
INSERT INTO `inv_member` VALUES ('25890', '13636639068', '25889', '898837ea4edbe7f33805fceaecd4d777', 'c5dfc201095a12e6fc76a637c95d015e', '0.01000', '1528854771', '117.136.8.230', '1528854795', '1', '1', '10', null, null, null, null, null, null, null, null, '0', '0', '1528905599', '1', '0.00000', '1');
INSERT INTO `inv_member` VALUES ('25891', '15392873696', '25888', '424e94b0c4574f13771df2719cadae97', 'cf7fb8eba635716364690aab4450b39d', '0.00000', '1529484162', '221.234.141.221', '1529484205', '1', '1', '10', null, null, null, null, null, null, null, null, '0', '0', '1530719999', '1', '0.00000', '1');
INSERT INTO `inv_member` VALUES ('25892', '13818599590', '25889', '2c76d92c8a00f595dfafeb77e228e21d', '2c76d92c8a00f595dfafeb77e228e21d', '1497.47000', '1530085300', '223.104.212.195', '1531742152', '1', '2', '0', '丁大强', 'fdksluxn', '13818599590', null, '', '325609198209283395', '', null, '876', '0', '1531756799', '1', '0.00000', '1');
INSERT INTO `inv_member` VALUES ('25893', '15944034175', '25889', '30dbdb2654341220cc8d2344f21ee8da', '30dbdb2654341220cc8d2344f21ee8da', '3.63000', '1531627654', '139.214.251.134', '1531627666', '1', '2', '0', '李阿敏', '15944034175', '15944034175', null, '', '310829199205062283', '', null, '880', '0', '1532015999', '1', '0.00000', '1');
INSERT INTO `inv_member` VALUES ('25888', '18672123233', '0', 'e10adc3949ba59abbe56e057f20f883e', 'c33367701511b4f6020ec61ded352059', '42537.89450', '1528825231', '101.90.254.23', '1528867924', '1', '2', '0', '', '', '', null, '', '', '', null, '752', '2', '1528905599', '1', '0.00000', '1');

-- ----------------------------
-- Table structure for `inv_message`
-- ----------------------------
DROP TABLE IF EXISTS `inv_message`;
CREATE TABLE `inv_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `content` char(100) NOT NULL,
  `is_look` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`,`create_time`,`is_look`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_message
-- ----------------------------
INSERT INTO `inv_message` VALUES ('1', '5', '1528692189', '你有新的点对点订单', '1');
INSERT INTO `inv_message` VALUES ('2', '4', '1528692538', '你的点对点交易订单已被对方取消交易', '2');
INSERT INTO `inv_message` VALUES ('3', '4', '1528692558', '你有新的点对点订单', '2');
INSERT INTO `inv_message` VALUES ('4', '4', '1528697922', '你的点对点交易订单已完成', '2');
INSERT INTO `inv_message` VALUES ('5', '4', '1528698024', '你有新的点对点订单', '2');
INSERT INTO `inv_message` VALUES ('6', '4', '1528698584', '你的点对点交易订单已完成', '2');
INSERT INTO `inv_message` VALUES ('7', '4', '1528716299', '你有新的点对点订单', '2');
INSERT INTO `inv_message` VALUES ('8', '4', '1528716338', '你的点对点交易订单已完成', '2');
INSERT INTO `inv_message` VALUES ('9', '8', '1528716658', '你有新的点对点订单', '1');
INSERT INTO `inv_message` VALUES ('10', '8', '1528732545', '你的点对点交易订单已完成', '1');
INSERT INTO `inv_message` VALUES ('11', '4', '1528732575', '你有新的点对点订单', '2');
INSERT INTO `inv_message` VALUES ('12', '4', '1528792596', '你在新手挂单中的挂单有新的动态', '2');
INSERT INTO `inv_message` VALUES ('13', '8', '1528792726', '你在新手挂单中的挂单对方已确认付款', '1');
INSERT INTO `inv_message` VALUES ('14', '4', '1528792763', '你在新手挂单中的挂单已交易完成', '2');
INSERT INTO `inv_message` VALUES ('15', '4', '1528792820', '你的点对点交易订单已完成', '2');
INSERT INTO `inv_message` VALUES ('16', '25889', '1529826487', '你在新手挂单中的挂单已被取消交易', '1');
INSERT INTO `inv_message` VALUES ('17', '25889', '1531064083', '你在新手挂单中的挂单已被取消交易', '1');

-- ----------------------------
-- Table structure for `inv_money_log`
-- ----------------------------
DROP TABLE IF EXISTS `inv_money_log`;
CREATE TABLE `inv_money_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `type` tinyint(2) NOT NULL DEFAULT '1',
  `money_begin` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `money` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `money_end` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `create_time` int(11) NOT NULL,
  `remark` char(200) DEFAULT NULL,
  `oid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=430 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_money_log
-- ----------------------------
INSERT INTO `inv_money_log` VALUES ('1', '4', '7', '0.00000', '0.01000', '0.01000', '1528690783', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('2', '5', '7', '51000.00000', '0.01000', '51000.01000', '1528691670', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('3', '6', '7', '50000.00000', '0.01000', '50000.01000', '1528691716', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('4', '4', '4', '50000.00000', '-260.00000', '49740.00000', '1528692189', '转账给17551040815', null);
INSERT INTO `inv_money_log` VALUES ('5', '4', '2', '49740.00000', '-10.00000', '49730.00000', '1528692256', '购买一代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('6', '4', '2', '49730.00000', '-50.00000', '49680.00000', '1528692260', '购买二代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('7', '4', '2', '49680.00000', '-250.00000', '49430.00000', '1528692262', '购买三代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('8', '4', '2', '49430.00000', '-1250.00000', '48180.00000', '1528692266', '购买四代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('9', '4', '2', '48180.00000', '-6250.00000', '41930.00000', '1528692282', '购买五代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('10', '4', '2', '41930.00000', '-1250.00000', '40680.00000', '1528692286', '购买四代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('11', '5', '2', '51000.01000', '-10.00000', '50990.01000', '1528692301', '购买一代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('12', '5', '2', '50990.01000', '-50.00000', '50940.01000', '1528692311', '购买二代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('13', '5', '2', '50940.01000', '-250.00000', '50690.01000', '1528692314', '购买三代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('14', '5', '2', '50690.01000', '-1250.00000', '49440.01000', '1528692318', '购买四代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('15', '5', '2', '49440.01000', '-6250.00000', '43190.01000', '1528692321', '购买五代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('16', '4', '4', '40680.00000', '260.00000', '40940.00000', '1528692538', '[17551040815]取消交易', null);
INSERT INTO `inv_money_log` VALUES ('17', '5', '4', '43190.01000', '-130.00000', '43060.01000', '1528692558', '转账给18121111885', null);
INSERT INTO `inv_money_log` VALUES ('18', '4', '2', '40940.00000', '-10.00000', '40930.00000', '1528697066', '购买一代电竞战机成功', '0');
INSERT INTO `inv_money_log` VALUES ('19', '4', '4', '40930.00000', '100.00000', '41030.00000', '1528697922', '收到用户[17551040815]转账', null);
INSERT INTO `inv_money_log` VALUES ('20', '7', '7', '0.00000', '0.01000', '0.01000', '1528698005', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('21', '5', '4', '43060.01000', '-1300.00000', '41760.01000', '1528698024', '转账给18121111885', null);
INSERT INTO `inv_money_log` VALUES ('22', '4', '4', '41030.00000', '1000.00000', '42030.00000', '1528698584', '收到用户[17551040815]转账', null);
INSERT INTO `inv_money_log` VALUES ('23', '5', '4', '41760.01000', '-130.00000', '41630.01000', '1528716299', '转账给18121111885', null);
INSERT INTO `inv_money_log` VALUES ('24', '4', '4', '42030.00000', '100.00000', '42130.00000', '1528716338', '收到用户[17551040815]转账', null);
INSERT INTO `inv_money_log` VALUES ('25', '4', '5', '42130.00000', '0.00900', '42130.00900', '1528716608', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('26', '8', '7', '50000.00000', '0.01000', '50000.01000', '1528716614', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('27', '4', '4', '42130.00900', '-1300.00000', '40830.00900', '1528716658', '转账给13098888675', null);
INSERT INTO `inv_money_log` VALUES ('28', '8', '4', '50000.01000', '1000.00000', '51000.01000', '1528732545', '收到用户[18121111885]转账', null);
INSERT INTO `inv_money_log` VALUES ('29', '8', '4', '51000.01000', '-2600.00000', '48400.01000', '1528732575', '转账给18121111885', null);
INSERT INTO `inv_money_log` VALUES ('30', '6', '3', '50000.01000', '0.16700', '50000.17700', '1528778069', '战机F6441430611收益', '2');
INSERT INTO `inv_money_log` VALUES ('31', '6', '7', '50000.17700', '0.01000', '50000.18700', '1528780013', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('32', '7', '7', '0.01000', '0.01000', '0.02000', '1528780762', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('33', '4', '3', '40830.00900', '0.16700', '40830.17600', '1528778100', '战机F4536490611收益', '3');
INSERT INTO `inv_money_log` VALUES ('34', '4', '3', '40830.17600', '0.16700', '40830.34300', '1528778656', '战机F4174890611收益', '4');
INSERT INTO `inv_money_log` VALUES ('35', '4', '3', '40830.34300', '0.86100', '40831.20400', '1528778660', '战机S4296080611收益', '5');
INSERT INTO `inv_money_log` VALUES ('36', '4', '3', '40831.20400', '4.44500', '40835.64900', '1528778662', '战机T4124820611收益', '6');
INSERT INTO `inv_money_log` VALUES ('37', '4', '3', '40835.64900', '22.91700', '40858.56600', '1528778666', '战机R4517400611收益', '7');
INSERT INTO `inv_money_log` VALUES ('38', '4', '3', '40858.56600', '118.05600', '40976.62200', '1528778682', '战机V4913460611收益', '8');
INSERT INTO `inv_money_log` VALUES ('39', '4', '3', '40976.62200', '22.91700', '40999.53900', '1528778686', '战机R4568190611收益', '9');
INSERT INTO `inv_money_log` VALUES ('40', '4', '3', '40999.53900', '0.18000', '40999.71900', '1528783466', '战机F4643940611收益', '15');
INSERT INTO `inv_money_log` VALUES ('41', '4', '7', '40999.71900', '0.01000', '40999.72900', '1528790940', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('42', '4', '5', '40999.72900', '0.00900', '40999.73800', '1528791333', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('43', '8', '6', '48400.01000', '-2.60000', '48397.41000', '1528792596', '新手挂单区中卖出', null);
INSERT INTO `inv_money_log` VALUES ('44', '4', '6', '40999.73800', '2.00000', '41001.73800', '1528792763', '新手挂单区中买入', null);
INSERT INTO `inv_money_log` VALUES ('45', '4', '4', '41001.73800', '2000.00000', '43001.73800', '1528792820', '收到用户[13098888675]转账', null);
INSERT INTO `inv_money_log` VALUES ('46', '9', '7', '0.00000', '0.01000', '0.01000', '1528819809', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('47', '9', '1', '0.01000', '10000.00000', '10000.01000', '1528820129', '2018-06-13 00:15:29后台充值', '0');
INSERT INTO `inv_money_log` VALUES ('48', '9', '2', '10000.01000', '-6250.00000', '3750.01000', '1528820443', '购买国际契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('49', '9', '2', '3750.01000', '-1250.00000', '2500.01000', '1528820517', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('50', '9', '2', '2500.01000', '-1250.00000', '1250.01000', '1528820519', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('51', '9', '2', '1250.01000', '-50.00000', '1200.01000', '1528820528', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('52', '9', '2', '1200.01000', '-50.00000', '1150.01000', '1528820530', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('53', '9', '2', '1150.01000', '-50.00000', '1100.01000', '1528820533', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('54', '9', '2', '1100.01000', '-250.00000', '850.01000', '1528820536', '购买市级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('55', '9', '2', '850.01000', '-250.00000', '600.01000', '1528820538', '购买市级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('56', '9', '2', '600.01000', '-250.00000', '350.01000', '1528820540', '购买市级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('57', '9', '2', '350.01000', '-250.00000', '100.01000', '1528820543', '购买市级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('58', '9', '2', '100.01000', '-50.00000', '50.01000', '1528820550', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('59', '9', '2', '50.01000', '-50.00000', '0.01000', '1528820553', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('60', '10', '7', '0.00000', '0.01000', '0.01000', '1528821009', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('61', '4', '7', '43001.73800', '0.01000', '43001.74800', '1528823629', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('62', '102', '7', '0.00000', '0.01000', '0.01000', '1528825271', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('63', '25888', '7', '0.01000', '0.01000', '0.02000', '1528826129', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('64', '25889', '7', '0.00000', '0.01000', '0.01000', '1528826709', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('65', '25890', '7', '0.00000', '0.01000', '0.01000', '1528854804', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('66', '25889', '2', '51000.00000', '-1250.00000', '49750.00000', '1528867570', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('67', '25888', '2', '50000.00000', '-6250.00000', '43750.00000', '1528867931', '购买国际契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('68', '25888', '2', '43750.00000', '-1250.00000', '42500.00000', '1528867937', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('69', '25889', '3', '49750.00000', '0.18000', '49750.18000', '1528912789', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('70', '25889', '3', '49750.18000', '0.18000', '49750.36000', '1528999189', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('71', '25889', '3', '49750.36000', '0.18000', '49750.54000', '1529085589', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('72', '25889', '3', '49750.54000', '0.18000', '49750.72000', '1529171989', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('73', '25889', '3', '49750.72000', '0.18000', '49750.90000', '1529258389', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('74', '25889', '3', '49750.90000', '0.18000', '49751.08000', '1529344789', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('75', '25889', '3', '49751.08000', '0.18000', '49751.26000', '1529431189', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('76', '25889', '3', '49751.26000', '0.18000', '49751.44000', '1529517589', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('77', '25889', '3', '49751.44000', '0.18000', '49751.62000', '1529603989', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('78', '25889', '3', '49751.62000', '0.18000', '49751.80000', '1529690389', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('79', '25889', '3', '49751.80000', '0.18000', '49751.98000', '1529776789', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('80', '25889', '3', '49751.98000', '118.05800', '49870.03800', '1528913476', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('81', '25889', '3', '49870.03800', '118.05800', '49988.09600', '1528999876', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('82', '25889', '3', '49988.09600', '118.05800', '50106.15400', '1529086276', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('83', '25889', '3', '50106.15400', '118.05800', '50224.21200', '1529172676', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('84', '25889', '3', '50224.21200', '118.05800', '50342.27000', '1529259076', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('85', '25889', '3', '50342.27000', '118.05800', '50460.32800', '1529345476', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('86', '25889', '3', '50460.32800', '118.05800', '50578.38600', '1529431876', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('87', '25889', '3', '50578.38600', '118.05800', '50696.44400', '1529518276', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('88', '25889', '3', '50696.44400', '118.05800', '50814.50200', '1529604676', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('89', '25889', '3', '50814.50200', '118.05800', '50932.56000', '1529691076', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('90', '25889', '3', '50932.56000', '118.05800', '51050.61800', '1529777476', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('91', '25889', '3', '51050.61800', '33.34000', '51083.95800', '1528953970', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('92', '25889', '3', '51083.95800', '33.34000', '51117.29800', '1529040370', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('93', '25889', '3', '51117.29800', '33.34000', '51150.63800', '1529126770', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('94', '25889', '3', '51150.63800', '33.34000', '51183.97800', '1529213170', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('95', '25889', '3', '51183.97800', '33.34000', '51217.31800', '1529299570', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('96', '25889', '3', '51217.31800', '33.34000', '51250.65800', '1529385970', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('97', '25889', '3', '51250.65800', '33.34000', '51283.99800', '1529472370', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('98', '25889', '3', '51283.99800', '33.34000', '51317.33800', '1529558770', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('99', '25889', '3', '51317.33800', '33.34000', '51350.67800', '1529645170', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('100', '25889', '3', '51350.67800', '33.34000', '51384.01800', '1529731570', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('101', '25889', '3', '51384.01800', '33.34000', '51417.35800', '1529817970', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('102', '25888', '5', '42500.00000', '7.57890', '42507.57890', '1529826194', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('103', '25889', '7', '51417.35800', '0.01000', '51417.36800', '1529826198', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('104', '25889', '2', '51417.36800', '-1250.00000', '50167.36800', '1529826218', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('105', '25889', '2', '50167.36800', '-250.00000', '49917.36800', '1529826230', '购买市级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('106', '25889', '2', '49917.36800', '-250.00000', '49667.36800', '1529826232', '购买市级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('107', '25889', '2', '49667.36800', '-250.00000', '49417.36800', '1529826235', '购买市级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('108', '25889', '2', '49417.36800', '-250.00000', '49167.36800', '1529826238', '购买市级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('109', '25889', '2', '49167.36800', '-50.00000', '49117.36800', '1529826249', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('110', '25889', '2', '49117.36800', '-50.00000', '49067.36800', '1529826251', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('111', '25889', '2', '49067.36800', '-50.00000', '49017.36800', '1529826254', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('112', '25889', '2', '49017.36800', '-50.00000', '48967.36800', '1529826256', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('113', '25889', '2', '48967.36800', '-50.00000', '48917.36800', '1529826259', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('114', '25889', '2', '48917.36800', '-50.00000', '48867.36800', '1529826267', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('115', '25889', '2', '48867.36800', '-50.00000', '48817.36800', '1529826269', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('116', '25889', '2', '48817.36800', '-50.00000', '48767.36800', '1529826272', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('117', '25889', '2', '48767.36800', '-50.00000', '48717.36800', '1529826278', '购买城主契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('118', '25888', '5', '42507.57890', '7.57890', '42515.15780', '1529856908', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('119', '25889', '7', '48717.36800', '0.01000', '48717.37800', '1529856912', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('120', '25889', '3', '48717.37800', '0.18000', '48717.55800', '1529863189', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('121', '25889', '3', '48717.55800', '0.18000', '48717.73800', '1529949589', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('122', '25889', '3', '48717.73800', '0.18000', '48717.91800', '1530035989', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('123', '25889', '3', '48717.91800', '118.05800', '48835.97600', '1529863876', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('124', '25889', '3', '48835.97600', '118.05800', '48954.03400', '1529950276', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('125', '25889', '3', '48954.03400', '118.05800', '49072.09200', '1530036676', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('126', '25889', '3', '49072.09200', '33.34000', '49105.43200', '1529904370', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('127', '25889', '3', '49105.43200', '33.34000', '49138.77200', '1529990770', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('128', '25889', '3', '49138.77200', '33.34000', '49172.11200', '1530077170', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('129', '25889', '3', '49172.11200', '33.34000', '49205.45200', '1529912618', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('130', '25889', '3', '49205.45200', '33.34000', '49238.79200', '1529999018', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('131', '25889', '3', '49238.79200', '5.47000', '49244.26200', '1529912630', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('132', '25889', '3', '49244.26200', '5.47000', '49249.73200', '1529999030', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('133', '25889', '3', '49249.73200', '5.47000', '49255.20200', '1529912633', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('134', '25889', '3', '49255.20200', '5.47000', '49260.67200', '1529999033', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('135', '25889', '3', '49260.67200', '5.47000', '49266.14200', '1529912635', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('136', '25889', '3', '49266.14200', '5.47000', '49271.61200', '1529999035', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('137', '25889', '3', '49271.61200', '5.47000', '49277.08200', '1529912638', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('138', '25889', '3', '49277.08200', '5.47000', '49282.55200', '1529999038', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('139', '25889', '3', '49282.55200', '1.03000', '49283.58200', '1529912649', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('140', '25889', '3', '49283.58200', '1.03000', '49284.61200', '1529999049', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('141', '25889', '3', '49284.61200', '1.03000', '49285.64200', '1529912654', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('142', '25889', '3', '49285.64200', '1.03000', '49286.67200', '1529999054', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('143', '25889', '3', '49286.67200', '1.03000', '49287.70200', '1529912657', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('144', '25889', '3', '49287.70200', '1.03000', '49288.73200', '1529999057', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('145', '25889', '3', '49288.73200', '1.03000', '49289.76200', '1529912667', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('146', '25889', '3', '49289.76200', '1.03000', '49290.79200', '1529999067', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('147', '25889', '3', '49290.79200', '1.03000', '49291.82200', '1529912678', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('148', '25889', '3', '49291.82200', '1.03000', '49292.85200', '1529999078', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('149', '25888', '5', '42515.15780', '7.57890', '42522.73670', '1530085093', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('150', '25889', '7', '49292.85200', '0.01000', '49292.86200', '1530085113', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('151', '25892', '7', '0.00000', '0.01000', '0.01000', '1530085356', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('152', '25889', '3', '49292.86200', '0.18000', '49293.04200', '1530122389', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('153', '25889', '3', '49293.04200', '0.18000', '49293.22200', '1530208789', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('154', '25889', '3', '49293.22200', '0.18000', '49293.40200', '1530295189', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('155', '25889', '3', '49293.40200', '0.18000', '49293.58200', '1530381589', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('156', '25889', '3', '49293.58200', '0.18000', '49293.76200', '1530467989', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('157', '25889', '3', '49293.76200', '0.18000', '49293.94200', '1530554389', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('158', '25889', '3', '49293.94200', '0.18000', '49294.12200', '1530640789', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('159', '25889', '3', '49294.12200', '0.18000', '49294.30200', '1530727189', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('160', '25889', '3', '49294.30200', '0.18000', '49294.48200', '1530813589', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('161', '25889', '3', '49294.48200', '0.18000', '49294.66200', '1530899989', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('162', '25889', '3', '49294.66200', '0.18000', '49294.84200', '1530986389', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('163', '25889', '3', '49294.84200', '118.05800', '49412.90000', '1530123076', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('164', '25889', '3', '49412.90000', '118.05800', '49530.95800', '1530209476', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('165', '25889', '3', '49530.95800', '118.05800', '49649.01600', '1530295876', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('166', '25889', '3', '49649.01600', '118.05800', '49767.07400', '1530382276', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('167', '25889', '3', '49767.07400', '118.05800', '49885.13200', '1530468676', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('168', '25889', '3', '49885.13200', '118.05800', '50003.19000', '1530555076', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('169', '25889', '3', '50003.19000', '118.05800', '50121.24800', '1530641476', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('170', '25889', '3', '50121.24800', '118.05800', '50239.30600', '1530727876', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('171', '25889', '3', '50239.30600', '118.05800', '50357.36400', '1530814276', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('172', '25889', '3', '50357.36400', '118.05800', '50475.42200', '1530900676', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('173', '25889', '3', '50475.42200', '118.05800', '50593.48000', '1530987076', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('174', '25889', '3', '50593.48000', '33.34000', '50626.82000', '1530163570', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('175', '25889', '3', '50626.82000', '33.34000', '50660.16000', '1530249970', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('176', '25889', '3', '50660.16000', '33.34000', '50693.50000', '1530336370', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('177', '25889', '3', '50693.50000', '33.34000', '50726.84000', '1530422770', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('178', '25889', '3', '50726.84000', '33.34000', '50760.18000', '1530509170', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('179', '25889', '3', '50760.18000', '33.34000', '50793.52000', '1530595570', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('180', '25889', '3', '50793.52000', '33.34000', '50826.86000', '1530681970', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('181', '25889', '3', '50826.86000', '33.34000', '50860.20000', '1530768370', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('182', '25889', '3', '50860.20000', '33.34000', '50893.54000', '1530854770', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('183', '25889', '3', '50893.54000', '33.34000', '50926.88000', '1530941170', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('184', '25889', '3', '50926.88000', '33.34000', '50960.22000', '1531027570', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('185', '25889', '3', '50960.22000', '33.34000', '50993.56000', '1530085418', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('186', '25889', '3', '50993.56000', '33.34000', '51026.90000', '1530171818', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('187', '25889', '3', '51026.90000', '33.34000', '51060.24000', '1530258218', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('188', '25889', '3', '51060.24000', '33.34000', '51093.58000', '1530344618', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('189', '25889', '3', '51093.58000', '33.34000', '51126.92000', '1530431018', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('190', '25889', '3', '51126.92000', '33.34000', '51160.26000', '1530517418', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('191', '25889', '3', '51160.26000', '33.34000', '51193.60000', '1530603818', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('192', '25889', '3', '51193.60000', '33.34000', '51226.94000', '1530690218', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('193', '25889', '3', '51226.94000', '33.34000', '51260.28000', '1530776618', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('194', '25889', '3', '51260.28000', '33.34000', '51293.62000', '1530863018', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('195', '25889', '3', '51293.62000', '33.34000', '51326.96000', '1530949418', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('196', '25889', '3', '51326.96000', '33.34000', '51360.30000', '1531035818', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('197', '25889', '3', '51360.30000', '5.47000', '51365.77000', '1530085430', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('198', '25889', '3', '51365.77000', '5.47000', '51371.24000', '1530171830', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('199', '25889', '3', '51371.24000', '5.47000', '51376.71000', '1530258230', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('200', '25889', '3', '51376.71000', '5.47000', '51382.18000', '1530344630', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('201', '25889', '3', '51382.18000', '5.47000', '51387.65000', '1530431030', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('202', '25889', '3', '51387.65000', '5.47000', '51393.12000', '1530517430', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('203', '25889', '3', '51393.12000', '5.47000', '51398.59000', '1530603830', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('204', '25889', '3', '51398.59000', '5.47000', '51404.06000', '1530690230', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('205', '25889', '3', '51404.06000', '5.47000', '51409.53000', '1530776630', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('206', '25889', '3', '51409.53000', '5.47000', '51415.00000', '1530863030', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('207', '25889', '3', '51415.00000', '5.47000', '51420.47000', '1530949430', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('208', '25889', '3', '51420.47000', '5.47000', '51425.94000', '1531035830', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('209', '25889', '3', '51425.94000', '5.47000', '51431.41000', '1530085433', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('210', '25889', '3', '51431.41000', '5.47000', '51436.88000', '1530171833', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('211', '25889', '3', '51436.88000', '5.47000', '51442.35000', '1530258233', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('212', '25889', '3', '51442.35000', '5.47000', '51447.82000', '1530344633', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('213', '25889', '3', '51447.82000', '5.47000', '51453.29000', '1530431033', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('214', '25889', '3', '51453.29000', '5.47000', '51458.76000', '1530517433', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('215', '25889', '3', '51458.76000', '5.47000', '51464.23000', '1530603833', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('216', '25889', '3', '51464.23000', '5.47000', '51469.70000', '1530690233', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('217', '25889', '3', '51469.70000', '5.47000', '51475.17000', '1530776633', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('218', '25889', '3', '51475.17000', '5.47000', '51480.64000', '1530863033', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('219', '25889', '3', '51480.64000', '5.47000', '51486.11000', '1530949433', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('220', '25889', '3', '51486.11000', '5.47000', '51491.58000', '1531035833', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('221', '25889', '3', '51491.58000', '5.47000', '51497.05000', '1530085435', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('222', '25889', '3', '51497.05000', '5.47000', '51502.52000', '1530171835', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('223', '25889', '3', '51502.52000', '5.47000', '51507.99000', '1530258235', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('224', '25889', '3', '51507.99000', '5.47000', '51513.46000', '1530344635', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('225', '25889', '3', '51513.46000', '5.47000', '51518.93000', '1530431035', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('226', '25889', '3', '51518.93000', '5.47000', '51524.40000', '1530517435', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('227', '25889', '3', '51524.40000', '5.47000', '51529.87000', '1530603835', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('228', '25889', '3', '51529.87000', '5.47000', '51535.34000', '1530690235', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('229', '25889', '3', '51535.34000', '5.47000', '51540.81000', '1530776635', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('230', '25889', '3', '51540.81000', '5.47000', '51546.28000', '1530863035', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('231', '25889', '3', '51546.28000', '5.47000', '51551.75000', '1530949435', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('232', '25889', '3', '51551.75000', '5.47000', '51557.22000', '1531035835', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('233', '25889', '3', '51557.22000', '5.47000', '51562.69000', '1530085438', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('234', '25889', '3', '51562.69000', '5.47000', '51568.16000', '1530171838', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('235', '25889', '3', '51568.16000', '5.47000', '51573.63000', '1530258238', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('236', '25889', '3', '51573.63000', '5.47000', '51579.10000', '1530344638', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('237', '25889', '3', '51579.10000', '5.47000', '51584.57000', '1530431038', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('238', '25889', '3', '51584.57000', '5.47000', '51590.04000', '1530517438', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('239', '25889', '3', '51590.04000', '5.47000', '51595.51000', '1530603838', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('240', '25889', '3', '51595.51000', '5.47000', '51600.98000', '1530690238', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('241', '25889', '3', '51600.98000', '5.47000', '51606.45000', '1530776638', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('242', '25889', '3', '51606.45000', '5.47000', '51611.92000', '1530863038', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('243', '25889', '3', '51611.92000', '5.47000', '51617.39000', '1530949438', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('244', '25889', '3', '51617.39000', '5.47000', '51622.86000', '1531035838', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('245', '25889', '3', '51622.86000', '1.03000', '51623.89000', '1530085449', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('246', '25889', '3', '51623.89000', '1.03000', '51624.92000', '1530171849', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('247', '25889', '3', '51624.92000', '1.03000', '51625.95000', '1530258249', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('248', '25889', '3', '51625.95000', '1.03000', '51626.98000', '1530344649', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('249', '25889', '3', '51626.98000', '1.03000', '51628.01000', '1530431049', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('250', '25889', '3', '51628.01000', '1.03000', '51629.04000', '1530517449', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('251', '25889', '3', '51629.04000', '1.03000', '51630.07000', '1530603849', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('252', '25889', '3', '51630.07000', '1.03000', '51631.10000', '1530690249', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('253', '25889', '3', '51631.10000', '1.03000', '51632.13000', '1530776649', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('254', '25889', '3', '51632.13000', '1.03000', '51633.16000', '1530863049', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('255', '25889', '3', '51633.16000', '1.03000', '51634.19000', '1530949449', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('256', '25889', '3', '51634.19000', '1.03000', '51635.22000', '1531035849', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('257', '25889', '3', '51635.22000', '1.03000', '51636.25000', '1530085454', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('258', '25889', '3', '51636.25000', '1.03000', '51637.28000', '1530171854', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('259', '25889', '3', '51637.28000', '1.03000', '51638.31000', '1530258254', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('260', '25889', '3', '51638.31000', '1.03000', '51639.34000', '1530344654', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('261', '25889', '3', '51639.34000', '1.03000', '51640.37000', '1530431054', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('262', '25889', '3', '51640.37000', '1.03000', '51641.40000', '1530517454', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('263', '25889', '3', '51641.40000', '1.03000', '51642.43000', '1530603854', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('264', '25889', '3', '51642.43000', '1.03000', '51643.46000', '1530690254', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('265', '25889', '3', '51643.46000', '1.03000', '51644.49000', '1530776654', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('266', '25889', '3', '51644.49000', '1.03000', '51645.52000', '1530863054', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('267', '25889', '3', '51645.52000', '1.03000', '51646.55000', '1530949454', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('268', '25889', '3', '51646.55000', '1.03000', '51647.58000', '1531035854', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('269', '25889', '3', '51647.58000', '1.03000', '51648.61000', '1530085457', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('270', '25889', '3', '51648.61000', '1.03000', '51649.64000', '1530171857', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('271', '25889', '3', '51649.64000', '1.03000', '51650.67000', '1530258257', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('272', '25889', '3', '51650.67000', '1.03000', '51651.70000', '1530344657', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('273', '25889', '3', '51651.70000', '1.03000', '51652.73000', '1530431057', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('274', '25889', '3', '51652.73000', '1.03000', '51653.76000', '1530517457', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('275', '25889', '3', '51653.76000', '1.03000', '51654.79000', '1530603857', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('276', '25889', '3', '51654.79000', '1.03000', '51655.82000', '1530690257', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('277', '25889', '3', '51655.82000', '1.03000', '51656.85000', '1530776657', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('278', '25889', '3', '51656.85000', '1.03000', '51657.88000', '1530863057', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('279', '25889', '3', '51657.88000', '1.03000', '51658.91000', '1530949457', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('280', '25889', '3', '51658.91000', '1.03000', '51659.94000', '1531035857', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('281', '25889', '3', '51659.94000', '1.03000', '51660.97000', '1530085467', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('282', '25889', '3', '51660.97000', '1.03000', '51662.00000', '1530171867', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('283', '25889', '3', '51662.00000', '1.03000', '51663.03000', '1530258267', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('284', '25889', '3', '51663.03000', '1.03000', '51664.06000', '1530344667', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('285', '25889', '3', '51664.06000', '1.03000', '51665.09000', '1530431067', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('286', '25889', '3', '51665.09000', '1.03000', '51666.12000', '1530517467', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('287', '25889', '3', '51666.12000', '1.03000', '51667.15000', '1530603867', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('288', '25889', '3', '51667.15000', '1.03000', '51668.18000', '1530690267', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('289', '25889', '3', '51668.18000', '1.03000', '51669.21000', '1530776667', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('290', '25889', '3', '51669.21000', '1.03000', '51670.24000', '1530863067', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('291', '25889', '3', '51670.24000', '1.03000', '51671.27000', '1530949467', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('292', '25889', '3', '51671.27000', '1.03000', '51672.30000', '1531035867', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('293', '25889', '3', '51672.30000', '1.03000', '51673.33000', '1530085478', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('294', '25889', '3', '51673.33000', '1.03000', '51674.36000', '1530171878', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('295', '25889', '3', '51674.36000', '1.03000', '51675.39000', '1530258278', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('296', '25889', '3', '51675.39000', '1.03000', '51676.42000', '1530344678', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('297', '25889', '3', '51676.42000', '1.03000', '51677.45000', '1530431078', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('298', '25889', '3', '51677.45000', '1.03000', '51678.48000', '1530517478', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('299', '25889', '3', '51678.48000', '1.03000', '51679.51000', '1530603878', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('300', '25889', '3', '51679.51000', '1.03000', '51680.54000', '1530690278', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('301', '25889', '3', '51680.54000', '1.03000', '51681.57000', '1530776678', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('302', '25889', '3', '51681.57000', '1.03000', '51682.60000', '1530863078', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('303', '25889', '3', '51682.60000', '1.03000', '51683.63000', '1530949478', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('304', '25889', '3', '51683.63000', '1.03000', '51684.66000', '1531035878', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('305', '25888', '5', '42522.73670', '7.57890', '42530.31560', '1531064038', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('306', '25889', '7', '51684.66000', '0.01000', '51684.67000', '1531064125', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('307', '25889', '3', '51684.67000', '0.18000', '51684.85000', '1531072789', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('308', '25889', '3', '51684.85000', '0.18000', '51685.03000', '1531159189', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('309', '25889', '3', '51685.03000', '0.18000', '51685.21000', '1531245589', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('310', '25889', '3', '51685.21000', '0.18000', '51685.39000', '1531331989', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('311', '25889', '3', '51685.39000', '0.18000', '51685.57000', '1531418389', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('312', '25889', '3', '51685.57000', '0.18000', '51685.75000', '1531504789', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('313', '25889', '3', '51685.75000', '0.18000', '51685.93000', '1531591189', '战机F2588990613收益', '33');
INSERT INTO `inv_money_log` VALUES ('314', '25889', '3', '51685.93000', '118.05800', '51803.98800', '1531073476', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('315', '25889', '3', '51803.98800', '118.05800', '51922.04600', '1531159876', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('316', '25889', '3', '51922.04600', '118.05800', '52040.10400', '1531246276', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('317', '25889', '3', '52040.10400', '118.05800', '52158.16200', '1531332676', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('318', '25889', '3', '52158.16200', '118.05800', '52276.22000', '1531419076', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('319', '25889', '3', '52276.22000', '118.05800', '52394.27800', '1531505476', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('320', '25889', '3', '52394.27800', '118.05800', '52512.33600', '1531591876', '战机V2588930613收益', '34');
INSERT INTO `inv_money_log` VALUES ('321', '25889', '3', '52512.33600', '33.34000', '52545.67600', '1531113970', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('322', '25889', '3', '52545.67600', '33.34000', '52579.01600', '1531200370', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('323', '25889', '3', '52579.01600', '33.34000', '52612.35600', '1531286770', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('324', '25889', '3', '52612.35600', '33.34000', '52645.69600', '1531373170', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('325', '25889', '3', '52645.69600', '33.34000', '52679.03600', '1531459570', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('326', '25889', '3', '52679.03600', '33.34000', '52712.37600', '1531545970', '战机R2588970613收益', '35');
INSERT INTO `inv_money_log` VALUES ('327', '25889', '3', '52712.37600', '33.34000', '52745.71600', '1531122218', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('328', '25889', '3', '52745.71600', '33.34000', '52779.05600', '1531208618', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('329', '25889', '3', '52779.05600', '33.34000', '52812.39600', '1531295018', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('330', '25889', '3', '52812.39600', '33.34000', '52845.73600', '1531381418', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('331', '25889', '3', '52845.73600', '33.34000', '52879.07600', '1531467818', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('332', '25889', '3', '52879.07600', '33.34000', '52912.41600', '1531554218', '战机R2588920624收益', '38');
INSERT INTO `inv_money_log` VALUES ('333', '25889', '3', '52912.41600', '5.47000', '52917.88600', '1531122230', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('334', '25889', '3', '52917.88600', '5.47000', '52923.35600', '1531208630', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('335', '25889', '3', '52923.35600', '5.47000', '52928.82600', '1531295030', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('336', '25889', '3', '52928.82600', '5.47000', '52934.29600', '1531381430', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('337', '25889', '3', '52934.29600', '5.47000', '52939.76600', '1531467830', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('338', '25889', '3', '52939.76600', '5.47000', '52945.23600', '1531554230', '战机T2588990624收益', '39');
INSERT INTO `inv_money_log` VALUES ('339', '25889', '3', '52945.23600', '5.47000', '52950.70600', '1531122233', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('340', '25889', '3', '52950.70600', '5.47000', '52956.17600', '1531208633', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('341', '25889', '3', '52956.17600', '5.47000', '52961.64600', '1531295033', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('342', '25889', '3', '52961.64600', '5.47000', '52967.11600', '1531381433', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('343', '25889', '3', '52967.11600', '5.47000', '52972.58600', '1531467833', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('344', '25889', '3', '52972.58600', '5.47000', '52978.05600', '1531554233', '战机T2588960624收益', '40');
INSERT INTO `inv_money_log` VALUES ('345', '25889', '3', '52978.05600', '5.47000', '52983.52600', '1531122235', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('346', '25889', '3', '52983.52600', '5.47000', '52988.99600', '1531208635', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('347', '25889', '3', '52988.99600', '5.47000', '52994.46600', '1531295035', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('348', '25889', '3', '52994.46600', '5.47000', '52999.93600', '1531381435', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('349', '25889', '3', '52999.93600', '5.47000', '53005.40600', '1531467835', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('350', '25889', '3', '53005.40600', '5.47000', '53010.87600', '1531554235', '战机T2588970624收益', '41');
INSERT INTO `inv_money_log` VALUES ('351', '25889', '3', '53010.87600', '5.47000', '53016.34600', '1531122238', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('352', '25889', '3', '53016.34600', '5.47000', '53021.81600', '1531208638', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('353', '25889', '3', '53021.81600', '5.47000', '53027.28600', '1531295038', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('354', '25889', '3', '53027.28600', '5.47000', '53032.75600', '1531381438', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('355', '25889', '3', '53032.75600', '5.47000', '53038.22600', '1531467838', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('356', '25889', '3', '53038.22600', '5.47000', '53043.69600', '1531554238', '战机T2588920624收益', '42');
INSERT INTO `inv_money_log` VALUES ('357', '25889', '3', '53043.69600', '1.03000', '53044.72600', '1531122249', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('358', '25889', '3', '53044.72600', '1.03000', '53045.75600', '1531208649', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('359', '25889', '3', '53045.75600', '1.03000', '53046.78600', '1531295049', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('360', '25889', '3', '53046.78600', '1.03000', '53047.81600', '1531381449', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('361', '25889', '3', '53047.81600', '1.03000', '53048.84600', '1531467849', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('362', '25889', '3', '53048.84600', '1.03000', '53049.87600', '1531554249', '战机S2588930624收益', '43');
INSERT INTO `inv_money_log` VALUES ('363', '25889', '3', '53049.87600', '1.03000', '53050.90600', '1531122254', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('364', '25889', '3', '53050.90600', '1.03000', '53051.93600', '1531208654', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('365', '25889', '3', '53051.93600', '1.03000', '53052.96600', '1531295054', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('366', '25889', '3', '53052.96600', '1.03000', '53053.99600', '1531381454', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('367', '25889', '3', '53053.99600', '1.03000', '53055.02600', '1531467854', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('368', '25889', '3', '53055.02600', '1.03000', '53056.05600', '1531554254', '战机S2588980624收益', '44');
INSERT INTO `inv_money_log` VALUES ('369', '25889', '3', '53056.05600', '1.03000', '53057.08600', '1531122257', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('370', '25889', '3', '53057.08600', '1.03000', '53058.11600', '1531208657', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('371', '25889', '3', '53058.11600', '1.03000', '53059.14600', '1531295057', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('372', '25889', '3', '53059.14600', '1.03000', '53060.17600', '1531381457', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('373', '25889', '3', '53060.17600', '1.03000', '53061.20600', '1531467857', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('374', '25889', '3', '53061.20600', '1.03000', '53062.23600', '1531554257', '战机S2588990624收益', '45');
INSERT INTO `inv_money_log` VALUES ('375', '25889', '3', '53062.23600', '1.03000', '53063.26600', '1531122267', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('376', '25889', '3', '53063.26600', '1.03000', '53064.29600', '1531208667', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('377', '25889', '3', '53064.29600', '1.03000', '53065.32600', '1531295067', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('378', '25889', '3', '53065.32600', '1.03000', '53066.35600', '1531381467', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('379', '25889', '3', '53066.35600', '1.03000', '53067.38600', '1531467867', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('380', '25889', '3', '53067.38600', '1.03000', '53068.41600', '1531554267', '战机S2588960624收益', '46');
INSERT INTO `inv_money_log` VALUES ('381', '25889', '3', '53068.41600', '1.03000', '53069.44600', '1531122278', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('382', '25889', '3', '53069.44600', '1.03000', '53070.47600', '1531208678', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('383', '25889', '3', '53070.47600', '1.03000', '53071.50600', '1531295078', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('384', '25889', '3', '53071.50600', '1.03000', '53072.53600', '1531381478', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('385', '25889', '3', '53072.53600', '1.03000', '53073.56600', '1531467878', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('386', '25889', '3', '53073.56600', '1.03000', '53074.59600', '1531554278', '战机S2588940624收益', '47');
INSERT INTO `inv_money_log` VALUES ('387', '25888', '5', '42530.31560', '7.57890', '42537.89450', '1531627066', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('388', '25893', '7', '0.00000', '0.01000', '0.01000', '1531627688', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('389', '25893', '1', '0.01000', '10000.00000', '10000.01000', '1531628329', '2018-07-15 12:18:49后台充值', '0');
INSERT INTO `inv_money_log` VALUES ('390', '25892', '1', '0.01000', '10000.00000', '10000.01000', '1531628683', '2018-07-15 12:24:43后台充值', '0');
INSERT INTO `inv_money_log` VALUES ('391', '25889', '5', '53074.59600', '0.00900', '53074.60500', '1531628756', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('392', '25892', '7', '10000.01000', '0.01000', '10000.02000', '1531628865', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('393', '25892', '2', '10000.02000', '-6250.00000', '3750.02000', '1531628995', '购买国际契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('394', '25892', '2', '3750.02000', '-1250.00000', '2500.02000', '1531629003', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('395', '25892', '2', '2500.02000', '-1250.00000', '1250.02000', '1531629471', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('396', '25889', '5', '53074.60500', '0.04500', '53074.65000', '1531697865', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('397', '25893', '7', '10000.01000', '0.01000', '10000.02000', '1531697874', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('398', '25892', '3', '1250.02000', '0.18000', '1250.20000', '1531715049', '战机F2589260715收益', '53');
INSERT INTO `inv_money_log` VALUES ('399', '25892', '3', '1250.20000', '180.58000', '1430.78000', '1531715395', '战机V2589210715收益', '54');
INSERT INTO `inv_money_log` VALUES ('400', '25892', '3', '1430.78000', '33.34000', '1464.12000', '1531715403', '战机R2589280715收益', '55');
INSERT INTO `inv_money_log` VALUES ('401', '25892', '3', '1464.12000', '33.34000', '1497.46000', '1531715871', '战机R2589290715收益', '56');
INSERT INTO `inv_money_log` VALUES ('402', '25889', '5', '53074.65000', '10.59740', '53085.24740', '1531742153', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('403', '25892', '7', '1497.46000', '0.01000', '1497.47000', '1531742200', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('404', '25893', '3', '10000.02000', '0.18000', '10000.20000', '1531714796', '战机F2589390715收益', '48');
INSERT INTO `inv_money_log` VALUES ('405', '25893', '3', '10000.20000', '0.18000', '10000.38000', '1531801196', '战机F2589390715收益', '48');
INSERT INTO `inv_money_log` VALUES ('406', '25893', '3', '10000.38000', '0.18000', '10000.56000', '1531887596', '战机F2589390715收益', '48');
INSERT INTO `inv_money_log` VALUES ('407', '25893', '3', '10000.56000', '0.18000', '10000.74000', '1531714804', '战机F2589360715收益', '49');
INSERT INTO `inv_money_log` VALUES ('408', '25893', '3', '10000.74000', '0.18000', '10000.92000', '1531801204', '战机F2589360715收益', '49');
INSERT INTO `inv_money_log` VALUES ('409', '25893', '3', '10000.92000', '0.18000', '10001.10000', '1531887604', '战机F2589360715收益', '49');
INSERT INTO `inv_money_log` VALUES ('410', '25893', '3', '10001.10000', '0.18000', '10001.28000', '1531714819', '战机F2589330715收益', '50');
INSERT INTO `inv_money_log` VALUES ('411', '25893', '3', '10001.28000', '0.18000', '10001.46000', '1531801219', '战机F2589330715收益', '50');
INSERT INTO `inv_money_log` VALUES ('412', '25893', '3', '10001.46000', '0.18000', '10001.64000', '1531887619', '战机F2589330715收益', '50');
INSERT INTO `inv_money_log` VALUES ('413', '25893', '3', '10001.64000', '0.18000', '10001.82000', '1531714978', '战机F2589380715收益', '51');
INSERT INTO `inv_money_log` VALUES ('414', '25893', '3', '10001.82000', '0.18000', '10002.00000', '1531801378', '战机F2589380715收益', '51');
INSERT INTO `inv_money_log` VALUES ('415', '25893', '3', '10002.00000', '0.18000', '10002.18000', '1531887778', '战机F2589380715收益', '51');
INSERT INTO `inv_money_log` VALUES ('416', '25893', '3', '10002.18000', '0.18000', '10002.36000', '1531714988', '战机F2589370715收益', '52');
INSERT INTO `inv_money_log` VALUES ('417', '25893', '3', '10002.36000', '0.18000', '10002.54000', '1531801388', '战机F2589370715收益', '52');
INSERT INTO `inv_money_log` VALUES ('418', '25893', '3', '10002.54000', '0.18000', '10002.72000', '1531887788', '战机F2589370715收益', '52');
INSERT INTO `inv_money_log` VALUES ('419', '25889', '5', '53085.24740', '0.04500', '53085.29240', '1531960542', '1代动态奖', '0');
INSERT INTO `inv_money_log` VALUES ('420', '25893', '2', '10002.72000', '-6250.00000', '3752.72000', '1531960556', '购买国际契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('421', '25893', '2', '3752.72000', '-1250.00000', '2502.72000', '1531960589', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('422', '25893', '2', '2502.72000', '-1250.00000', '1252.72000', '1531960592', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('423', '25893', '2', '1252.72000', '-1250.00000', '2.72000', '1531960595', '购买洲级契约成功', '0');
INSERT INTO `inv_money_log` VALUES ('424', '25893', '7', '2.72000', '0.01000', '2.73000', '1531960623', '签到成功', '0');
INSERT INTO `inv_money_log` VALUES ('425', '25893', '3', '2.73000', '0.18000', '2.91000', '1531973996', '战机F2589390715收益', '48');
INSERT INTO `inv_money_log` VALUES ('426', '25893', '3', '2.91000', '0.18000', '3.09000', '1531974004', '战机F2589360715收益', '49');
INSERT INTO `inv_money_log` VALUES ('427', '25893', '3', '3.09000', '0.18000', '3.27000', '1531974019', '战机F2589330715收益', '50');
INSERT INTO `inv_money_log` VALUES ('428', '25893', '3', '3.27000', '0.18000', '3.45000', '1531974178', '战机F2589380715收益', '51');
INSERT INTO `inv_money_log` VALUES ('429', '25893', '3', '3.45000', '0.18000', '3.63000', '1531974188', '战机F2589370715收益', '52');

-- ----------------------------
-- Table structure for `inv_notice`
-- ----------------------------
DROP TABLE IF EXISTS `inv_notice`;
CREATE TABLE `inv_notice` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` char(255) NOT NULL,
  `content` varchar(8000) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `create_time` (`create_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公告表';

-- ----------------------------
-- Records of inv_notice
-- ----------------------------

-- ----------------------------
-- Table structure for `inv_order`
-- ----------------------------
DROP TABLE IF EXISTS `inv_order`;
CREATE TABLE `inv_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `buy_member_id` int(11) unsigned NOT NULL,
  `number` int(11) unsigned NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `create_time` int(11) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sale_member_id` int(11) unsigned NOT NULL DEFAULT '0',
  `sale_time` int(11) unsigned NOT NULL DEFAULT '0',
  `image` varchar(200) NOT NULL DEFAULT ' ',
  `pay_time` int(11) unsigned NOT NULL DEFAULT '0',
  `finish_time` int(11) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL,
  `extra` text NOT NULL,
  `change_money` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `buy_member_id` (`buy_member_id`,`create_time`,`status`,`sale_member_id`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_order
-- ----------------------------
INSERT INTO `inv_order` VALUES ('1', '201806111242247385528523', '4', '2', '2.10', '1528692144', '4', '8', '1528792596', 'http://www.pcc.one/uploads/180612/575-981715ac92f5684b7720f59b20d907ab.png', '1528792726', '1528792762', '1', '', '0.60');
INSERT INTO `inv_order` VALUES ('2', '201806130957097508300719', '25889', '10', '1.00', '1528855029', '5', '0', '0', ' ', '0', '0', '1', '[{\"cancel_time\":1529826487,\"handle_id\":\"25889\",\"handle_name\":\"13761605266\"}]', '3.00');
INSERT INTO `inv_order` VALUES ('3', '201806241548324753753614', '25889', '10', '1.00', '1529826512', '5', '0', '0', ' ', '0', '0', '1', '[{\"cancel_time\":1531064083,\"handle_id\":\"25889\",\"handle_name\":\"13761605266\"}]', '3.00');
INSERT INTO `inv_order` VALUES ('4', '201807082335139397949205', '25889', '10', '1.30', '1531064113', '1', '0', '0', ' ', '0', '0', '1', '', '3.00');

-- ----------------------------
-- Table structure for `inv_product`
-- ----------------------------
DROP TABLE IF EXISTS `inv_product`;
CREATE TABLE `inv_product` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` char(255) NOT NULL,
  `category_name` char(255) NOT NULL,
  `t` char(10) NOT NULL,
  `price` decimal(15,5) NOT NULL,
  `day_rate` decimal(15,5) NOT NULL,
  `day` int(5) NOT NULL COMMENT '持续时间',
  `max` int(11) NOT NULL DEFAULT '0' COMMENT '限购数量',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '运算力',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:上架出售  2:下架',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_product
-- ----------------------------
INSERT INTO `inv_product` VALUES ('1', '个人契约', '个人契约', 'F', '10.00000', '0.18000', '180', '10', '1', '1');
INSERT INTO `inv_product` VALUES ('2', '城主契约', '城主契约', 'S', '50.00000', '1.03000', '170', '6', '5', '1');
INSERT INTO `inv_product` VALUES ('3', '市级契约', '市级契约', 'T', '250.00000', '5.47000', '160', '4', '25', '1');
INSERT INTO `inv_product` VALUES ('4', '洲级契约', '洲级契约', 'R', '1250.00000', '33.34000', '150', '2', '125', '1');
INSERT INTO `inv_product` VALUES ('5', '国际契约', '国际契约', 'V', '6250.00000', '180.58000', '140', '1', '625', '1');

-- ----------------------------
-- Table structure for `inv_product_order`
-- ----------------------------
DROP TABLE IF EXISTS `inv_product_order`;
CREATE TABLE `inv_product_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_number` char(50) NOT NULL COMMENT '购买理财产品流水号（唯一）',
  `product_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL COMMENT '会员主键id',
  `product_name` char(255) NOT NULL,
  `product_category_name` char(255) NOT NULL,
  `price` int(11) NOT NULL COMMENT '购买理财产品价格',
  `day_rate` decimal(15,5) NOT NULL,
  `day` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `create_time` int(11) NOT NULL COMMENT '下单时间',
  `t_time` int(11) NOT NULL,
  `t_count` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `type` tinyint(1) NOT NULL COMMENT '1:购买 2:后台发放',
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_number` (`product_number`),
  KEY `product_id` (`member_id`),
  KEY `status` (`status`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_product_order
-- ----------------------------
INSERT INTO `inv_product_order` VALUES ('1', 'F5130450611', '1', '5', '一代电竞战机', '一代电竞战机', '10', '0.16700', '180', '1', '1528691640', '1528691640', '0', '1', '5');
INSERT INTO `inv_product_order` VALUES ('2', 'F6441430611', '1', '6', '一代电竞战机', '一代电竞战机', '10', '0.16700', '180', '1', '1528691669', '1528778069', '1', '1', '5');
INSERT INTO `inv_product_order` VALUES ('3', 'F4536490611', '1', '4', '一代电竞战机', '一代电竞战机', '10', '0.16700', '180', '1', '1528691700', '1528778100', '1', '1', '5');
INSERT INTO `inv_product_order` VALUES ('4', 'F4174890611', '1', '4', '一代电竞战机', '一代电竞战机', '10', '0.16700', '180', '1', '1528692256', '1528778656', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('5', 'S4296080611', '2', '4', '二代电竞战机', '二代电竞战机', '50', '0.86100', '180', '5', '1528692260', '1528778660', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('6', 'T4124820611', '3', '4', '三代电竞战机', '三代电竞战机', '250', '4.44500', '180', '25', '1528692262', '1528778662', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('7', 'R4517400611', '4', '4', '四代电竞战机', '四代电竞战机', '1250', '22.91700', '180', '125', '1528692266', '1528778666', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('8', 'V4913460611', '5', '4', '五代电竞战机', '五代电竞战机', '6250', '118.05600', '180', '625', '1528692282', '1528778682', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('9', 'R4568190611', '4', '4', '四代电竞战机', '四代电竞战机', '1250', '22.91700', '180', '125', '1528692286', '1528778686', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('10', 'F5777590611', '1', '5', '一代电竞战机', '一代电竞战机', '10', '0.16700', '180', '1', '1528692301', '1528692301', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('11', 'S5733680611', '2', '5', '二代电竞战机', '二代电竞战机', '50', '0.86100', '180', '5', '1528692311', '1528692311', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('12', 'T5999470611', '3', '5', '三代电竞战机', '三代电竞战机', '250', '4.44500', '180', '25', '1528692314', '1528692314', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('13', 'R5927360611', '4', '5', '四代电竞战机', '四代电竞战机', '1250', '22.91700', '180', '125', '1528692318', '1528692318', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('14', 'V5451930611', '5', '5', '五代电竞战机', '五代电竞战机', '6250', '118.05600', '180', '625', '1528692321', '1528692321', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('15', 'F4643940611', '1', '4', '一代电竞战机', '一代电竞战机', '10', '0.18000', '180', '1', '1528697066', '1528783466', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('16', 'F8253680611', '1', '8', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1528716588', '1528716588', '0', '1', '5');
INSERT INTO `inv_product_order` VALUES ('17', 'F7119300612', '1', '7', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1528780901', '1528780901', '0', '1', '5');
INSERT INTO `inv_product_order` VALUES ('18', 'F9961580613', '1', '9', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1528819868', '1528819868', '0', '1', '5');
INSERT INTO `inv_product_order` VALUES ('19', 'V9323290613', '5', '9', '国际契约', '省级契约', '6250', '118.05800', '140', '625', '1528820443', '1528820443', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('20', 'R9850290613', '4', '9', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1528820517', '1528820517', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('21', 'R9532340613', '4', '9', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1528820519', '1528820519', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('22', 'S9694040613', '2', '9', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1528820528', '1528820528', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('23', 'S9965190613', '2', '9', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1528820530', '1528820530', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('24', 'S9490540613', '2', '9', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1528820533', '1528820533', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('25', 'T9617620613', '3', '9', '市级契约', '市级契约', '250', '5.47000', '160', '25', '1528820536', '1528820536', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('26', 'T9500560613', '3', '9', '市级契约', '市级契约', '250', '5.47000', '160', '25', '1528820538', '1528820538', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('27', 'T9548890613', '3', '9', '市级契约', '市级契约', '250', '5.47000', '160', '25', '1528820540', '1528820540', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('28', 'T9547110613', '3', '9', '市级契约', '市级契约', '250', '5.47000', '160', '25', '1528820543', '1528820543', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('29', 'S9375660613', '2', '9', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1528820550', '1528820550', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('30', 'S9396350613', '2', '9', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1528820553', '1528820553', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('31', 'S4672040613', '2', '4', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1528823625', '1528823625', '0', '1', '4');
INSERT INTO `inv_product_order` VALUES ('32', 'F2588880613', '1', '25888', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1528826088', '1528826088', '0', '1', '5');
INSERT INTO `inv_product_order` VALUES ('33', 'F2588990613', '1', '25889', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1528826389', '1531591189', '32', '1', '5');
INSERT INTO `inv_product_order` VALUES ('34', 'V2588930613', '5', '25889', '国际契约', '省级契约', '6250', '118.05800', '140', '625', '1528827076', '1531591876', '32', '1', '2');
INSERT INTO `inv_product_order` VALUES ('35', 'R2588970613', '4', '25889', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1528867570', '1531545970', '31', '1', '1');
INSERT INTO `inv_product_order` VALUES ('36', 'V2588870613', '5', '25888', '国际契约', '国际契约', '6250', '118.05800', '140', '625', '1528867931', '1528867931', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('37', 'R2588850613', '4', '25888', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1528867937', '1528867937', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('38', 'R2588920624', '4', '25889', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1529826218', '1531554218', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('39', 'T2588990624', '3', '25889', '市级契约', '市级契约', '250', '5.47000', '160', '25', '1529826230', '1531554230', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('40', 'T2588960624', '3', '25889', '市级契约', '市级契约', '250', '5.47000', '160', '25', '1529826233', '1531554233', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('41', 'T2588970624', '3', '25889', '市级契约', '市级契约', '250', '5.47000', '160', '25', '1529826235', '1531554235', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('42', 'T2588920624', '3', '25889', '市级契约', '市级契约', '250', '5.47000', '160', '25', '1529826238', '1531554238', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('43', 'S2588930624', '2', '25889', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1529826249', '1531554249', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('44', 'S2588980624', '2', '25889', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1529826254', '1531554254', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('45', 'S2588990624', '2', '25889', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1529826257', '1531554257', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('46', 'S2588960624', '2', '25889', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1529826267', '1531554267', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('47', 'S2588940624', '2', '25889', '城主契约', '城主契约', '50', '1.03000', '170', '5', '1529826278', '1531554278', '20', '1', '1');
INSERT INTO `inv_product_order` VALUES ('48', 'F2589390715', '1', '25893', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1531628396', '1531973996', '4', '1', '5');
INSERT INTO `inv_product_order` VALUES ('49', 'F2589360715', '1', '25893', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1531628404', '1531974004', '4', '1', '5');
INSERT INTO `inv_product_order` VALUES ('50', 'F2589330715', '1', '25893', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1531628419', '1531974019', '4', '1', '5');
INSERT INTO `inv_product_order` VALUES ('51', 'F2589380715', '1', '25893', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1531628578', '1531974178', '4', '1', '5');
INSERT INTO `inv_product_order` VALUES ('52', 'F2589370715', '1', '25893', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1531628588', '1531974188', '4', '1', '5');
INSERT INTO `inv_product_order` VALUES ('53', 'F2589260715', '1', '25892', '个人契约', '个人契约', '10', '0.18000', '180', '1', '1531628649', '1531715049', '1', '1', '5');
INSERT INTO `inv_product_order` VALUES ('54', 'V2589210715', '5', '25892', '国际契约', '国际契约', '6250', '180.58000', '140', '625', '1531628995', '1531715395', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('55', 'R2589280715', '4', '25892', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1531629003', '1531715403', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('56', 'R2589290715', '4', '25892', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1531629471', '1531715871', '1', '1', '1');
INSERT INTO `inv_product_order` VALUES ('57', 'V2589360719', '5', '25893', '国际契约', '国际契约', '6250', '180.58000', '140', '625', '1531960556', '1531960556', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('58', 'R2589390719', '4', '25893', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1531960589', '1531960589', '0', '1', '1');
INSERT INTO `inv_product_order` VALUES ('59', 'R2589310719', '4', '25893', '洲级契约', '洲级契约', '1250', '33.34000', '150', '125', '1531960595', '1531960595', '0', '1', '1');

-- ----------------------------
-- Table structure for `inv_real_user_info`
-- ----------------------------
DROP TABLE IF EXISTS `inv_real_user_info`;
CREATE TABLE `inv_real_user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `realname` varchar(255) DEFAULT NULL,
  `idcard` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `bankcard` varchar(255) DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=930 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_real_user_info
-- ----------------------------
INSERT INTO `inv_real_user_info` VALUES ('927', '7', '夏常贵', '421123199206040017', '15629141716', '6225882715494073', '2018-06-12 13:21:41');
INSERT INTO `inv_real_user_info` VALUES ('928', '9', '范有龙', '362502198710160018', '13761605266', '6222021001000037041', '2018-06-13 00:11:08');
INSERT INTO `inv_real_user_info` VALUES ('929', '25889', '范有龙', '362502198710160018', '13761605266', '6222021001000037041', '2018-06-13 01:59:49');

-- ----------------------------
-- Table structure for `inv_receiving_address`
-- ----------------------------
DROP TABLE IF EXISTS `inv_receiving_address`;
CREATE TABLE `inv_receiving_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_receiving_address
-- ----------------------------

-- ----------------------------
-- Table structure for `inv_sign_log`
-- ----------------------------
DROP TABLE IF EXISTS `inv_sign_log`;
CREATE TABLE `inv_sign_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `money` decimal(15,5) NOT NULL,
  `create_time` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_sign_log
-- ----------------------------
INSERT INTO `inv_sign_log` VALUES ('1', '0.01000', '1528646400', '4');
INSERT INTO `inv_sign_log` VALUES ('2', '0.01000', '1528646400', '5');
INSERT INTO `inv_sign_log` VALUES ('3', '0.01000', '1528646400', '6');
INSERT INTO `inv_sign_log` VALUES ('4', '0.01000', '1528646400', '7');
INSERT INTO `inv_sign_log` VALUES ('5', '0.01000', '1528646400', '8');
INSERT INTO `inv_sign_log` VALUES ('6', '0.01000', '1528732800', '6');
INSERT INTO `inv_sign_log` VALUES ('7', '0.01000', '1528732800', '7');
INSERT INTO `inv_sign_log` VALUES ('8', '0.01000', '1528732800', '4');
INSERT INTO `inv_sign_log` VALUES ('9', '0.01000', '1528819200', '9');
INSERT INTO `inv_sign_log` VALUES ('10', '0.01000', '1528819200', '10');
INSERT INTO `inv_sign_log` VALUES ('11', '0.01000', '1528819200', '4');
INSERT INTO `inv_sign_log` VALUES ('12', '0.01000', '1528819200', '102');
INSERT INTO `inv_sign_log` VALUES ('13', '0.01000', '1528819200', '25888');
INSERT INTO `inv_sign_log` VALUES ('14', '0.01000', '1528819200', '25889');
INSERT INTO `inv_sign_log` VALUES ('15', '0.01000', '1528819200', '25890');
INSERT INTO `inv_sign_log` VALUES ('16', '0.01000', '1529769600', '25889');
INSERT INTO `inv_sign_log` VALUES ('17', '0.01000', '1529856000', '25889');
INSERT INTO `inv_sign_log` VALUES ('18', '0.01000', '1530028800', '25889');
INSERT INTO `inv_sign_log` VALUES ('19', '0.01000', '1530028800', '25892');
INSERT INTO `inv_sign_log` VALUES ('20', '0.01000', '1530979200', '25889');
INSERT INTO `inv_sign_log` VALUES ('21', '0.01000', '1531584000', '25893');
INSERT INTO `inv_sign_log` VALUES ('22', '0.01000', '1531584000', '25892');
INSERT INTO `inv_sign_log` VALUES ('23', '0.01000', '1531670400', '25893');
INSERT INTO `inv_sign_log` VALUES ('24', '0.01000', '1531670400', '25892');
INSERT INTO `inv_sign_log` VALUES ('25', '0.01000', '1531929600', '25893');

-- ----------------------------
-- Table structure for `inv_unit_price_log`
-- ----------------------------
DROP TABLE IF EXISTS `inv_unit_price_log`;
CREATE TABLE `inv_unit_price_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_unit_price_log
-- ----------------------------
INSERT INTO `inv_unit_price_log` VALUES ('1', '0.03', '1524322800');
INSERT INTO `inv_unit_price_log` VALUES ('2', '0.04', '1524326400');
INSERT INTO `inv_unit_price_log` VALUES ('3', '0.04', '1524330000');
INSERT INTO `inv_unit_price_log` VALUES ('4', '0.04', '1524369600');
INSERT INTO `inv_unit_price_log` VALUES ('5', '0.04', '1524373200');
INSERT INTO `inv_unit_price_log` VALUES ('6', '0.04', '1524376800');
INSERT INTO `inv_unit_price_log` VALUES ('7', '0.04', '1524380400');
INSERT INTO `inv_unit_price_log` VALUES ('8', '0.04', '1524384000');
INSERT INTO `inv_unit_price_log` VALUES ('9', '0.04', '1524391200');
INSERT INTO `inv_unit_price_log` VALUES ('10', '0.04', '1524398400');
INSERT INTO `inv_unit_price_log` VALUES ('11', '0.04', '1524402000');
INSERT INTO `inv_unit_price_log` VALUES ('12', '0.04', '1524405600');
INSERT INTO `inv_unit_price_log` VALUES ('13', '0.05', '1525262400');
INSERT INTO `inv_unit_price_log` VALUES ('14', '0.05', '1525266000');
INSERT INTO `inv_unit_price_log` VALUES ('15', '0.06', '1526486400');
INSERT INTO `inv_unit_price_log` VALUES ('16', '0.07', '1528689600');
INSERT INTO `inv_unit_price_log` VALUES ('17', '0.07', '1528693200');
INSERT INTO `inv_unit_price_log` VALUES ('18', '0.07', '1528696800');
INSERT INTO `inv_unit_price_log` VALUES ('19', '0.07', '1528714800');
INSERT INTO `inv_unit_price_log` VALUES ('20', '0.07', '1528729200');
INSERT INTO `inv_unit_price_log` VALUES ('21', '0.08', '1528732800');
INSERT INTO `inv_unit_price_log` VALUES ('22', '0.08', '1528736400');
INSERT INTO `inv_unit_price_log` VALUES ('23', '0.08', '1528779600');
INSERT INTO `inv_unit_price_log` VALUES ('24', '0.08', '1528790400');
INSERT INTO `inv_unit_price_log` VALUES ('25', '0.08', '1528812000');
INSERT INTO `inv_unit_price_log` VALUES ('26', '0.09', '1528819200');
INSERT INTO `inv_unit_price_log` VALUES ('27', '0.09', '1528822800');
INSERT INTO `inv_unit_price_log` VALUES ('28', '0.09', '1528851600');
INSERT INTO `inv_unit_price_log` VALUES ('29', '0.09', '1528855200');
INSERT INTO `inv_unit_price_log` VALUES ('30', '0.09', '1528862400');
INSERT INTO `inv_unit_price_log` VALUES ('31', '0.09', '1528866000');
INSERT INTO `inv_unit_price_log` VALUES ('32', '0.10', '1529823600');
INSERT INTO `inv_unit_price_log` VALUES ('33', '0.11', '1529856000');
INSERT INTO `inv_unit_price_log` VALUES ('34', '0.12', '1530082800');
INSERT INTO `inv_unit_price_log` VALUES ('35', '0.13', '1531062000');
INSERT INTO `inv_unit_price_log` VALUES ('36', '0.14', '1531623600');
INSERT INTO `inv_unit_price_log` VALUES ('37', '0.14', '1531627200');
INSERT INTO `inv_unit_price_log` VALUES ('38', '0.14', '1531641600');
INSERT INTO `inv_unit_price_log` VALUES ('39', '0.15', '1531695600');
INSERT INTO `inv_unit_price_log` VALUES ('40', '0.15', '1531738800');
INSERT INTO `inv_unit_price_log` VALUES ('41', '0.16', '1531958400');

-- ----------------------------
-- Table structure for `inv_user_action_log`
-- ----------------------------
DROP TABLE IF EXISTS `inv_user_action_log`;
CREATE TABLE `inv_user_action_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_user_action_log
-- ----------------------------
INSERT INTO `inv_user_action_log` VALUES ('1', '5', 'UPDATE_WEIXIN', '2018-06-11 12:51:54');
INSERT INTO `inv_user_action_log` VALUES ('2', '5', 'UPDATE_ZHIFUBAO', '2018-06-11 12:52:11');
INSERT INTO `inv_user_action_log` VALUES ('3', '5', 'UPDATE_ZHIFUBAO', '2018-06-11 12:52:15');
INSERT INTO `inv_user_action_log` VALUES ('4', '7', 'VERIFY_REALNAME', '2018-06-12 13:21:41');
INSERT INTO `inv_user_action_log` VALUES ('5', '9', 'VERIFY_REALNAME', '2018-06-13 00:11:08');
INSERT INTO `inv_user_action_log` VALUES ('6', '25889', 'VERIFY_REALNAME', '2018-06-13 01:59:49');
INSERT INTO `inv_user_action_log` VALUES ('7', '25893', 'UPDATE_WEIXIN', '2018-07-15 12:25:01');
INSERT INTO `inv_user_action_log` VALUES ('8', '25893', 'UPDATE_ZHIFUBAO', '2018-07-15 12:25:20');

-- ----------------------------
-- Table structure for `inv_web_config`
-- ----------------------------
DROP TABLE IF EXISTS `inv_web_config`;
CREATE TABLE `inv_web_config` (
  `name` char(50) NOT NULL,
  `key` char(50) NOT NULL,
  `value` char(255) NOT NULL,
  `order_by` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of inv_web_config
-- ----------------------------
INSERT INTO `inv_web_config` VALUES ('网站标题', 'title', 'PCC', '1');
INSERT INTO `inv_web_config` VALUES ('开启站点（1：开启 2：关闭）', 'start', '1', '2');
INSERT INTO `inv_web_config` VALUES ('站点关闭提示', 'close_notice', '维护期间，开网时间 08：00，敬请谅解。', '3');
INSERT INTO `inv_web_config` VALUES ('虚拟币名字', 'money_name', 'PCC', '4');
INSERT INTO `inv_web_config` VALUES ('开启交易市场（1：开启 2：关闭）', 'market', '1', '5');
INSERT INTO `inv_web_config` VALUES ('交易市场关闭提示', 'market_notice', '交易市场关闭提示', '6');
INSERT INTO `inv_web_config` VALUES ('普通矿工名字', 'k_0', '个人契约', '7');
INSERT INTO `inv_web_config` VALUES ('一级矿工名字', 'k_1', '城主契约', '8');
INSERT INTO `inv_web_config` VALUES ('二级矿工名字', 'k_2', '市级契约', '9');
INSERT INTO `inv_web_config` VALUES ('三级矿工名字', 'k_3', '洲级契约', '10');
INSERT INTO `inv_web_config` VALUES ('四级矿工名字', 'k_4', '国际契约', '11');
INSERT INTO `inv_web_config` VALUES ('是否开启注册送微型矿机（1：开启 2：关闭）', 'r_s', '2', '12');
INSERT INTO `inv_web_config` VALUES ('注册送微型矿机数量（已开启注册送矿机才有效）', 'r_s_n', '0', '13');
INSERT INTO `inv_web_config` VALUES ('系统开市时间（设置示例：01:00）', 'w_s', '00:05', '14');
INSERT INTO `inv_web_config` VALUES ('系统关市时间（设置示例：22:00）', 'w_e', '24:00', '15');
INSERT INTO `inv_web_config` VALUES ('是否开启注册（1：开启 2：关闭）', 'r_open', '1', '17');
INSERT INTO `inv_web_config` VALUES ('IP注册数量限制（只影响前端用户注册）', 'r_number', '3', '18');
INSERT INTO `inv_web_config` VALUES ('闭市提示信息', 'w_n', 'APP维护更新，临时关网，开网时间 08：00', '16');
INSERT INTO `inv_web_config` VALUES ('云之讯（sid）', 'yzx_sid', 'e9b370555f53aa7fa83c6d1547ecb1a2', '26');
INSERT INTO `inv_web_config` VALUES ('云之讯（token）', 'yzx_token', '36d2130718bb7d0717514a133c9d0cd6', '27');
INSERT INTO `inv_web_config` VALUES ('实名认证送矿机', 'auth_give', '1', '21');
INSERT INTO `inv_web_config` VALUES ('矿市开市时间', 'market_open', '00:05', '22');
INSERT INTO `inv_web_config` VALUES ('矿市闭市时间', 'market_close', '24:00', '23');
INSERT INTO `inv_web_config` VALUES ('矿市关闭提示', 'trade_market_notice', '闭市期间，开市时间 08:00 ~ 24:00', '24');
INSERT INTO `inv_web_config` VALUES ('用户验证次数', 'verify_count', '1', '25');
INSERT INTO `inv_web_config` VALUES ('云之讯（appid）', 'yzx_appid', 'ba18ab31883c40d08a817d7b6e7904e7', '28');
INSERT INTO `inv_web_config` VALUES ('云之讯-验证码（templateid）', 'yzx_templateid', '328594', '29');
INSERT INTO `inv_web_config` VALUES ('云之讯-交易通知（templateid）', 'yzx_templateid_notify', '328595', '30');
